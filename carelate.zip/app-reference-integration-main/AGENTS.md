<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- All clinic business rules (roles, daily limits, slot times, emergencies, notifications, sync) live in `src/lib/clinic-store.ts`; UI in `src/components/ClinicApp.tsx` only calls it — so rules are enforced and testable outside the UI.
- Data is offline-first: device copy plus a simulated main database in browser storage, merged last-updated-wins — matches the original app; swap the server layer later without changing the UI.
