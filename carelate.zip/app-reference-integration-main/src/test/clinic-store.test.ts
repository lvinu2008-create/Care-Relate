import { beforeEach, describe, expect, it } from "vitest";
import * as S from "@/lib/clinic-store";

const T = S.todayKey();
const D1 = S.addDays(T, 1),
  D2 = S.addDays(T, 2),
  D3 = S.addDays(T, 3);

beforeEach(() => {
  localStorage.clear();
  S.setSyncDelay(0);
  S.setForcedOffline(true); // keep tests deterministic; sync explicitly
  S.ensureSeed();
});
const asReception = () => S.login("reception", "reception123");
const asMeera = () => S.login("doctor", "doctor123");
const asArjun = () => S.login("arjun", "arjun123");
function newPatient(name = "Test Patient") {
  asReception();
  return S.savePatient({
    id: S.newId("P"),
    name,
    age: 30,
    gender: "Male",
    phone: "9000000000",
    address: "X",
  });
}
function fill(doctorId: string, date: string, n: number) {
  asReception();
  const ids: string[] = [];
  for (let i = 0; i < n; i++)
    ids.push(S.bookAppointment({ patientId: newPatient(`P${i}`).id, doctorId, date }).visit.id);
  return ids;
}
const setLimit = (id: string, n: number) => {
  asReception();
  S.setDailyLimit(id, n);
};

describe("existing rules", () => {
  it("device cleanup removes synced visits older than 30 days but keeps unsynced ones", () => {
    asMeera();
    const old = new Date(Date.now() - 40 * 864e5).toISOString();
    S.saveVisit({
      id: "X1",
      patientId: "P1001",
      visitDate: old,
      symptoms: ["Fever"],
      diagnosis: "",
      treatment: "",
      doctor: "Dr. Meera Nair",
    });
    S.cleanup();
    expect(S.getLocal().visits.some((v) => v.id === "X1")).toBe(true);
    const db = S.getLocal();
    db.visits = db.visits.map((v) => (v.id === "X1" ? { ...v, syncStatus: "synced" } : v));
    localStorage.setItem("clinic.local.v1", JSON.stringify(db));
    S.cleanup();
    expect(S.getLocal().visits.some((v) => v.id === "X1")).toBe(false);
  });
  it("last updated wins on conflicting edits", () => {
    const a = { id: "P1", updatedAt: "2026-10-30T10:00:00Z", phone: "9876" };
    const b = { id: "P1", updatedAt: "2026-10-30T11:00:00Z", phone: "9123" };
    expect(S.mergeLWW([b], [a])[0]?.phone).toBe("9123");
    expect(S.mergeLWW([a], [b])[0]?.phone).toBe("9123");
  });
  it("old visits default to completed", () => {
    expect(S.getLocal().visits.find((v) => v.id === "V002")?.status).toBe("completed");
  });
});

describe("daily limit", () => {
  it("allows booking under the limit and assigns 15-minute slots from 09:00", () => {
    setLimit("D1", 3);
    const [a, b] = fill("D1", D1, 2).map((id) => S.getLocal().visits.find((v) => v.id === id)!);
    // seed has one appointment on D1 for tomorrow at 09:00
    expect([a!.scheduledTime, b!.scheduledTime]).toEqual(["09:15", "09:30"]);
    expect(S.countVisitsForDoctor("D1", D1)).toBe(3);
  });
  it("allows booking exactly at the limit, rejects above it", () => {
    setLimit("D2", 2);
    fill("D2", D1, 2);
    expect(S.getCapacity("D2", D1).remaining).toBe(0);
    expect(() => fill("D2", D1, 1)).toThrow(/reached today's limit \(2\)/);
  });
  it("changing the limit takes effect and is validated 1–100", () => {
    setLimit("D2", 1);
    fill("D2", D1, 1);
    expect(() => fill("D2", D1, 1)).toThrow();
    setLimit("D2", 2);
    expect(() => fill("D2", D1, 1)).not.toThrow();
    expect(() => setLimit("D2", 0)).toThrow();
    expect(() => setLimit("D2", 101)).toThrow();
  });
  it("cancelled appointments do not count", () => {
    setLimit("D2", 1);
    const [id] = fill("D2", D1, 1);
    S.cancelAppointment(id!);
    expect(S.countVisitsForDoctor("D2", D1)).toBe(0);
  });
});

describe("emergency rescheduling", () => {
  it("moves a single day's patients to the next day as priority, ahead of normal bookings", () => {
    setLimit("D2", 5);
    const normal = fill("D2", D1, 1)[0]!;
    const affected = fill("D2", T, 2);
    asArjun();
    const ev = S.handleDoctorEmergency("D2", T, "Family emergency");
    // seed A004 is also on today for D2
    expect(ev).toHaveLength(3);
    const day = S.getLocal()
      .visits.filter((v) => v.doctorId === "D2" && v.date === D1 && v.status === "scheduled")
      .sort((a, b) => a.scheduledTime.localeCompare(b.scheduledTime));
    expect(day.slice(0, 3).every((v) => v.priority && v.rescheduledFrom === T)).toBe(true);
    expect(day.at(-1)!.id).toBe(normal);
    expect(day.map((v) => v.scheduledTime)).toEqual(["09:00", "09:15", "09:30", "09:45"]);
    expect(day.findIndex((v) => v.id === affected[0])).toBeLessThan(
      day.findIndex((v) => v.id === affected[1]),
    );
  });
  it("overflows beyond the daily limit and skips consecutive unavailable days", () => {
    setLimit("D2", 2);
    fill("D2", T, 1); // +A004 = 2 today
    fill("D2", D1, 1);
    asArjun();
    S.handleDoctorEmergency("D2", D2, "Conference");
    const ev = S.handleDoctorEmergency("D2", T, "Sick");
    const dates = ev.map((e) => e.newDate);
    expect(dates).toEqual([D1, D3]); // D1 has 1 free slot, D2 unavailable
    expect(S.countVisitsForDoctor("D2", D1)).toBe(2);
  });
  it("priority visits count towards capacity", () => {
    setLimit("D2", 2);
    asArjun();
    S.handleDoctorEmergency("D2", T, "Sick"); // moves A004 to D1
    fill("D2", D1, 1);
    expect(() => fill("D2", D1, 1)).toThrow(/limit/);
  });
  it("works offline then syncs, and the later device wins without duplicates", async () => {
    asArjun();
    S.handleDoctorEmergency("D2", T, "Sick");
    expect(S.getLocal().visits.find((v) => v.id === "A004")?.syncStatus).toBe("pending");
    S.setForcedOffline(false);
    await S.syncNow();
    const srv = S.getServer();
    expect(srv.visits.find((v) => v.id === "A004")?.date).toBe(D1);
    expect(srv.visits.filter((v) => v.id === "A004")).toHaveLength(1);
    const a = {
      ...srv.visits.find((v) => v.id === "A004")!,
      date: D2,
      updatedAt: "2099-01-01T10:00:00Z",
    };
    const b = { ...a, date: D3, updatedAt: "2099-01-01T11:00:00Z" };
    const merged = S.mergeLWW(S.mergeLWW(srv.visits, [b]), [a]);
    expect(merged.filter((v) => v.id === "A004")).toHaveLength(1);
    expect(merged.find((v) => v.id === "A004")?.date).toBe(D3);
  });
  it("doctors cannot declare an emergency for another doctor", () => {
    asMeera();
    expect(() => S.handleDoctorEmergency("D2", T, "x")).toThrow(/own schedule/);
  });
});

describe("notifications", () => {
  it("confirmation contains patient name, doctor, date and time", async () => {
    S.setForcedOffline(false);
    const p = newPatient("Ravi Test");
    const r = S.bookAppointment({ patientId: p.id, doctorId: "D1", date: D2 });
    expect(r.notification.status).toBe("sent");
    expect(r.notification.message).toBe(
      `Confirmed: Ravi Test, your visit with Dr. Meera Nair is on ${S.fmtDate(D2)} at 09:00.`,
    );
  });
  it("rescheduled message includes original date and reason; one per affected patient", () => {
    asArjun();
    S.handleDoctorEmergency("D2", T, "Sick");
    const n = S.getLocal().notifications.filter(
      (x) => x.kind === "rescheduled" && x.audience === "patient",
    );
    expect(n).toHaveLength(1);
    expect(n[0]!.message).toContain(`earlier session on ${S.fmtDate(T)}`);
    expect(n[0]!.message).toContain("Sick");
  });
  it("offline booking queues, sync sends, retry does not duplicate", async () => {
    const p = newPatient();
    const r = S.bookAppointment({ patientId: p.id, doctorId: "D1", date: D2 });
    expect(r.offline).toBe(true);
    expect(r.notification.status).toBe("queued");
    S.setForcedOffline(false);
    await S.syncNow();
    await S.syncNow();
    const ns = S.getLocal().notifications.filter(
      (x) => x.visitId === r.visit.id && x.audience === "patient",
    );
    expect(ns).toHaveLength(1);
    expect(ns[0]!.status).toBe("sent");
    S.sendConfirmation(S.getLocal().visits.find((v) => v.id === r.visit.id)!);
    expect(
      S.getLocal().notifications.filter(
        (x) => x.visitId === r.visit.id && x.audience === "patient",
      ),
    ).toHaveLength(1);
  });
  it("rejected offline booking creates a failed notification, no confirmation", async () => {
    const p = newPatient();
    const r = S.bookAppointment({ patientId: p.id, doctorId: "D1", date: D3 });
    // another device marks the doctor unavailable on the server first
    const srv = S.getServer();
    srv.doctors = srv.doctors.map((d) =>
      d.id === "D1" ? { ...d, unavailableDates: [D3], updatedAt: "2099-01-01T00:00:00Z" } : d,
    );
    localStorage.setItem("clinic.server.v1", JSON.stringify(srv));
    S.setForcedOffline(false);
    await S.syncNow();
    const ns = S.getLocal().notifications.filter(
      (x) => x.visitId === r.visit.id && x.audience === "patient",
    );
    expect(ns).toHaveLength(1);
    expect(ns[0]!.status).toBe("failed");
    expect(S.getLocal().visits.find((v) => v.id === r.visit.id)?.bookingStatus).toBe("rejected");
  });
  it("over-limit offline booking is preserved and flagged", async () => {
    setLimit("D2", 1);
    const p = newPatient();
    const r = S.bookAppointment({ patientId: p.id, doctorId: "D2", date: D3 });
    const srv = S.getServer();
    srv.visits.push({ ...r.visit, id: "OTHER", syncStatus: "synced", bookingStatus: "accepted" });
    srv.doctors = srv.doctors.map((d) => (d.id === "D2" ? { ...d, dailyLimit: 1 } : d));
    localStorage.setItem("clinic.server.v1", JSON.stringify(srv));
    S.setForcedOffline(false);
    await S.syncNow();
    const v = S.getLocal().visits.find((x) => x.id === r.visit.id)!;
    expect(v.status).toBe("scheduled");
    expect(v.bookingStatus).toBe("over_limit");
  });
});

describe("roles", () => {
  it("receptionist can register and book; doctor cannot book", () => {
    const p = newPatient();
    expect(() => S.bookAppointment({ patientId: p.id, doctorId: "D1", date: D2 })).not.toThrow();
    asMeera();
    expect(() => S.bookAppointment({ patientId: p.id, doctorId: "D1", date: D2 })).toThrow(
      /not allowed/,
    );
    expect(() => S.setDailyLimit("D1", 5)).toThrow(/not allowed/);
  });
  it("doctor sees only their own patients and cannot open another doctor's records", () => {
    asArjun();
    const scoped = S.getScoped();
    expect(scoped.visits.every((v) => v.doctorId === "D2")).toBe(true);
    expect(scoped.patients.map((p) => p.id)).toEqual(["P1005"]);
    expect(() => S.getPatientRecord("P1001")).toThrow(/not assigned/);
    expect(() => S.markCompleted("A001")).toThrow(/own schedule/);
  });
  it("doctor can complete their own visit", () => {
    asMeera();
    expect(S.markCompleted("A001").status).toBe("completed");
  });
  it("signed-out calls are rejected", () => {
    S.logout();
    expect(() => S.setDailyLimit("D1", 5)).toThrow(/sign in/);
  });
});
