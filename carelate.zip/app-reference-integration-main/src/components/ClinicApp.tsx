import { useEffect, useMemo, useState, useSyncExternalStore, type ReactNode } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  Bell,
  BriefcaseMedical,
  CalendarDays,
  CalendarPlus,
  CheckCircle2,
  ClipboardList,
  Database,
  Home,
  LogOut,
  Pencil,
  PlusCircle,
  RefreshCw,
  Search,
  Stethoscope,
  Trash2,
  UserPlus,
  Users,
  Wifi,
  WifiOff,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import * as S from "@/lib/clinic-store";

type Screen =
  | { name: "home" }
  | { name: "search" }
  | { name: "register" }
  | { name: "sync" }
  | { name: "book"; patientId?: string }
  | { name: "doctors" }
  | { name: "notifications" }
  | { name: "schedule" }
  | { name: "emergency" }
  | { name: "history"; id: string }
  | { name: "edit"; id: string }
  | { name: "visit"; id: string };

let ver = 0;
S.subscribe(() => {
  ver++;
});
function useStore() {
  useSyncExternalStore(
    S.subscribe,
    () => ver,
    () => 0,
  );
  const user = S.getUser();
  return {
    local: S.getScoped(user),
    all: S.getLocal(),
    server: S.getServer(),
    user,
    online: S.isOnline(),
    syncing: S.isSyncing(),
    conn: S.connectionState(),
    last: S.getLastSync(),
  };
}
type St = ReturnType<typeof useStore>;

const initials = (n: string) =>
  n
    .split(" ")
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
const errMsg = (e: unknown) => (e instanceof Error ? e.message : "Something went wrong");

function Badge({ status }: { status: S.SyncStatus }) {
  return status === "pending" ? (
    <span className="rounded-full bg-warning px-2 py-0.5 text-xs font-semibold text-warning-foreground">
      Pending
    </span>
  ) : (
    <span className="rounded-full bg-secondary px-2 py-0.5 text-xs font-semibold text-secondary-foreground">
      Synced
    </span>
  );
}
function Pill({
  tone,
  children,
}: {
  tone: "muted" | "warn" | "ok" | "bad" | "prio";
  children: ReactNode;
}) {
  const cls = {
    muted: "bg-secondary text-secondary-foreground",
    warn: "bg-warning text-warning-foreground",
    ok: "bg-success text-success-foreground",
    bad: "bg-destructive text-destructive-foreground",
    prio: "bg-priority text-priority-foreground",
  }[tone];
  return (
    <span className={`inline-block rounded-full px-2 py-0.5 text-xs font-semibold ${cls}`}>
      {children}
    </span>
  );
}
const NotifStatus = ({ s }: { s: S.NotificationStatus }) => (
  <Pill tone={s === "sent" ? "ok" : s === "failed" ? "bad" : "warn"}>
    {s === "sent" ? "Sent" : s === "failed" ? "Failed" : "Queued"}
  </Pill>
);
const VisitStatusPill = ({ v }: { v: S.Visit }) => (
  <Pill
    tone={
      v.status === "completed"
        ? "ok"
        : v.status === "cancelled"
          ? "bad"
          : v.status === "rescheduled"
            ? "warn"
            : "muted"
    }
  >
    {v.status[0]!.toUpperCase() + v.status.slice(1)}
  </Pill>
);

function useRoleTheme(st: St) {
  return st.user?.role === "receptionist"
    ? { bar: "bg-reception text-reception-foreground", soft: "bg-reception-soft" }
    : { bar: "bg-primary text-primary-foreground", soft: "bg-primary-soft" };
}
function Header({
  st,
  title,
  onBack,
  right,
}: {
  st: St;
  title: string;
  onBack?: () => void;
  right?: ReactNode;
}) {
  const t = useRoleTheme(st);
  return (
    <header className={`sticky top-0 z-10 flex h-16 items-center justify-between px-4 ${t.bar}`}>
      <button aria-label="Back" onClick={onBack} className="p-2">
        {onBack && <ArrowLeft className="h-5 w-5" />}
      </button>
      <h1 className="text-lg font-bold">{title}</h1>
      <div className="w-9">{right}</div>
    </header>
  );
}
const Card = ({ children, className = "" }: { children: ReactNode; className?: string }) => (
  <div className={`rounded-2xl border border-border bg-card p-4 ${className}`}>{children}</div>
);
const Field = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="block">
    <span className="mb-1.5 block text-sm font-semibold">{label}</span>
    {children}
  </label>
);
const inputCls =
  "w-full rounded-xl border border-input bg-card px-4 py-3 outline-none focus:ring-2 focus:ring-ring";
const primaryBtn =
  "flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3.5 font-bold text-primary-foreground disabled:opacity-50";
const ghostBtn =
  "flex items-center justify-center gap-1.5 rounded-xl border border-border px-3 py-2 text-sm font-semibold disabled:opacity-50";
const H2 = ({ children }: { children: ReactNode }) => (
  <h2 className="text-xl font-bold">{children}</h2>
);

function PriorityTag({ v }: { v: S.Visit }) {
  if (!v.priority) return null;
  return (
    <Pill tone="prio">
      Priority{v.rescheduledFrom ? ` – rescheduled from ${S.fmtDMY(v.rescheduledFrom)}` : ""}
    </Pill>
  );
}

function VisitCard({
  v,
  title,
  st,
  actions,
}: {
  v: S.Visit;
  title?: string;
  st?: St;
  actions?: ReactNode;
}) {
  const d = new Date(v.visitDate);
  const conf = st?.all.notifications
    .filter((n) => n.visitId === v.id && n.audience === "patient")
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
  return (
    <Card>
      <div className="flex items-start gap-3">
        <div className="rounded-md bg-primary px-2.5 py-1 text-center text-primary-foreground">
          <div className="text-lg font-bold leading-tight">{d.getDate()}</div>
          <div className="text-xs">
            {d.toLocaleString("en", { month: "short" })} {String(d.getFullYear()).slice(2)}
          </div>
        </div>
        <div className="min-w-0 flex-1">
          {title && <div className="font-bold">{title}</div>}
          <div className="font-bold">
            {v.status === "scheduled" ? `Appointment · ${v.scheduledTime}` : v.diagnosis || "Visit"}
          </div>
          <div className="text-sm text-muted-foreground">{v.doctor}</div>
          <div className="mt-1 flex flex-wrap gap-1">
            <VisitStatusPill v={v} />
            <PriorityTag v={v} />
            {v.bookingStatus === "awaiting_sync" && <Pill tone="warn">Awaiting sync</Pill>}
            {v.bookingStatus === "over_limit" && (
              <Pill tone="bad">Over limit – needs attention</Pill>
            )}
            {v.bookingStatus === "rejected" && <Pill tone="bad">Rejected</Pill>}
          </div>
        </div>
        <Badge status={v.syncStatus} />
      </div>
      {v.symptoms.length > 0 && (
        <div className="mt-3 border-t border-border pt-3">
          <div className="text-xs font-semibold tracking-wider text-muted-foreground">SYMPTOMS</div>
          <div className="mt-2 flex flex-wrap gap-2">
            {v.symptoms.map((s) => (
              <span
                key={s}
                className="rounded-full bg-secondary px-3 py-1 text-sm font-semibold text-secondary-foreground"
              >
                {s}
              </span>
            ))}
          </div>
        </div>
      )}
      {v.treatment && (
        <div className="mt-3 border-t border-border pt-3">
          <div className="text-xs font-semibold tracking-wider text-muted-foreground">
            TREATMENT
          </div>
          <div className="mt-1">{v.treatment}</div>
        </div>
      )}
      {v.rescheduleHistory?.length ? (
        <div className="mt-3 border-t border-border pt-3 text-sm">
          <div className="text-xs font-semibold tracking-wider text-muted-foreground">
            RESCHEDULED
          </div>
          {v.rescheduleHistory.map((h) => (
            <div key={h.at + h.to}>
              {S.fmtDate(h.from)} → {S.fmtDate(h.to)} · {h.reason}
            </div>
          ))}
        </div>
      ) : null}
      {conf && (
        <div className="mt-3 flex items-center justify-between gap-2 border-t border-border pt-3 text-sm">
          <span className="text-muted-foreground">Patient confirmation</span>
          <NotifStatus s={conf.status} />
        </div>
      )}
      {v.bookingNote && <p className="mt-2 text-sm text-destructive">{v.bookingNote}</p>}
      {actions && (
        <div className="mt-3 flex flex-wrap gap-2 border-t border-border pt-3">{actions}</div>
      )}
    </Card>
  );
}

function StatusBanner({ st, pending, onClick }: { st: St; pending: number; onClick?: () => void }) {
  const text =
    st.conn === "syncing"
      ? "Syncing…"
      : st.conn === "offline"
        ? `Offline — ${pending} records saved on device`
        : st.conn === "failed"
          ? "Sync failed — will retry"
          : pending
            ? `Online — ${pending} records pending sync`
            : "Online — all records synchronized";
  const cls =
    st.conn === "offline" || st.conn === "failed"
      ? "bg-destructive text-destructive-foreground"
      : pending || st.syncing
        ? "bg-warning text-warning-foreground"
        : "bg-secondary text-secondary-foreground";
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-2 rounded-xl px-4 py-3 text-left font-semibold ${cls}`}
    >
      {st.conn === "offline" ? (
        <WifiOff className="h-4 w-4" />
      ) : st.syncing ? (
        <RefreshCw className="h-4 w-4 animate-spin" />
      ) : (
        <Wifi className="h-4 w-4" />
      )}
      {text}
    </button>
  );
}

function Login() {
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [err, setErr] = useState("");
  return (
    <div className="min-h-screen">
      <div className="rounded-b-3xl bg-primary px-6 pb-8 pt-6 text-primary-foreground">
        <div className="mb-4 inline-flex rounded-xl bg-primary-soft p-3">
          <BriefcaseMedical className="h-7 w-7" />
        </div>
        <h1 className="text-3xl font-bold">Clinic Records</h1>
        <p className="mt-1 opacity-90">Offline-first patient records for rural clinics</p>
      </div>
      <form
        className="space-y-4 p-6"
        onSubmit={(e) => {
          e.preventDefault();
          if (!S.login(u, p)) setErr("Invalid username or password");
        }}
      >
        <h2 className="text-xl font-bold">Sign in</h2>
        <Field label="Username">
          <input
            className={inputCls}
            value={u}
            onChange={(e) => setU(e.target.value)}
            placeholder="reception or doctor"
            maxLength={50}
          />
        </Field>
        <Field label="Password">
          <input
            type="password"
            className={inputCls}
            value={p}
            onChange={(e) => setP(e.target.value)}
            maxLength={100}
          />
        </Field>
        {err && <p className="text-sm text-destructive">{err}</p>}
        <button className={primaryBtn}>Login</button>
        <p className="text-sm font-semibold text-muted-foreground">Quick fill for demo:</p>
        <div className="flex flex-wrap gap-2">
          {S.DEMO_ACCOUNTS.map((a) => (
            <button
              type="button"
              key={a.username}
              onClick={() => {
                setU(a.username);
                setP(a.pw);
              }}
              className="rounded-full border border-border px-4 py-2 text-sm font-semibold"
            >
              {a.role === "receptionist" ? "Receptionist" : a.name}
            </button>
          ))}
        </div>
      </form>
    </div>
  );
}

export function ClinicApp() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const c = S.initClinic();
    setReady(true);
    const off = S.onNotification((n) => {
      const u = S.getUser();
      if (!u) return;
      const mine =
        u.role === "receptionist"
          ? n.audience !== "doctor"
          : n.doctorId === u.doctorId && n.audience !== "reception";
      if (!mine) return;
      if (n.status === "failed") toast.error(n.message);
      else if (n.audience === "patient")
        toast.success(`Confirmation sent to ${n.patientName}`, { description: n.message });
      else toast(n.message);
    });
    return () => {
      c();
      off();
    };
  }, []);
  if (!ready) return <div className="min-h-screen bg-background" />;
  return (
    <div className="mx-auto min-h-screen max-w-md bg-background shadow-xl">
      <Shell />
      <Toaster position="top-center" />
    </div>
  );
}

function Shell() {
  const st = useStore();
  const [screen, go] = useState<Screen>({ name: "home" });
  const [stack, setStack] = useState<Screen[]>([]);
  const nav = (s: Screen) => {
    setStack((x) => [...x, screen]);
    go(s);
  };
  const back = () => {
    const prev = stack.at(-1) ?? { name: "home" as const };
    setStack((x) => x.slice(0, -1));
    go(prev);
  };
  const tab = (s: Screen) => {
    setStack([]);
    go(s);
  };
  useEffect(() => {
    setStack([]);
    go({ name: "home" });
  }, [st.user?.username]);
  if (!st.user) return <Login />;

  const pend = <T extends { syncStatus: S.SyncStatus }>(xs: T[]) =>
    xs.filter((x) => x.syncStatus === "pending").length;
  const pending = pend(st.all.patients) + pend(st.all.visits) + pend(st.all.doctors);
  const props = { st, nav, back, pending };
  const isRec = st.user.role === "receptionist";
  let body: ReactNode;
  switch (screen.name) {
    case "home":
      body = isRec ? <ReceptionHome {...props} /> : <DoctorHome {...props} />;
      break;
    case "search":
      body = <SearchScreen {...props} />;
      break;
    case "register":
      body = (
        <PatientForm
          {...props}
          onDone={(id) => {
            setStack([{ name: "home" }]);
            go({ name: "book", patientId: id });
          }}
        />
      );
      break;
    case "edit":
      body = <PatientForm {...props} id={screen.id} onDone={back} />;
      break;
    case "visit":
      body = <VisitForm {...props} id={screen.id} />;
      break;
    case "history":
      body = <History {...props} id={screen.id} />;
      break;
    case "sync":
      body = <SyncScreen {...props} />;
      break;
    case "book":
      body = (
        <BookScreen {...props} {...(screen.patientId ? { patientId: screen.patientId } : {})} />
      );
      break;
    case "doctors":
      body = <DoctorsScreen {...props} />;
      break;
    case "notifications":
      body = <NotificationsScreen {...props} />;
      break;
    case "schedule":
      body = <ScheduleScreen {...props} />;
      break;
    case "emergency":
      body = <EmergencyScreen {...props} />;
      break;
  }
  const unread = S.unreadCount(st.user);
  const tabs = isRec
    ? ([
        { n: "home", l: "Home", I: Home },
        { n: "book", l: "Book", I: CalendarPlus },
        { n: "search", l: "Patients", I: Search },
        { n: "doctors", l: "Doctors", I: Stethoscope },
        { n: "notifications", l: "Alerts", I: Bell },
      ] as const)
    : ([
        { n: "home", l: "Today", I: Home },
        { n: "schedule", l: "Schedule", I: CalendarDays },
        { n: "search", l: "Patients", I: Users },
        { n: "emergency", l: "Emergency", I: AlertTriangle },
        { n: "notifications", l: "Alerts", I: Bell },
      ] as const);
  return (
    <div className="pb-20">
      {body}
      <nav className="fixed bottom-0 left-1/2 z-20 grid w-full max-w-md -translate-x-1/2 grid-cols-5 border-t border-border bg-card py-2">
        {tabs.map(({ n, l, I }) => (
          <button
            key={n}
            onClick={() => tab({ name: n } as Screen)}
            className={`relative flex flex-col items-center gap-1 text-xs ${screen.name === n ? "font-semibold text-primary" : "text-muted-foreground"}`}
          >
            <I className="h-5 w-5" />
            {l}
            {n === "notifications" && unread > 0 && (
              <span className="absolute -top-1 right-4 rounded-full bg-destructive px-1.5 text-[10px] font-bold text-destructive-foreground">
                {unread}
              </span>
            )}
          </button>
        ))}
      </nav>
    </div>
  );
}

type P = { st: St; nav: (s: Screen) => void; back: () => void; pending: number };

function Hero({ st, subtitle, children }: { st: St; subtitle: string; children?: ReactNode }) {
  const t = useRoleTheme(st);
  const hour = new Date().getHours();
  const greet = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  return (
    <div className={`px-6 pb-6 pt-2 ${t.bar}`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="opacity-90">{greet},</p>
          <h1 className="text-2xl font-bold">{st.user!.name}</h1>
          <p className="text-xs font-semibold uppercase opacity-80">{subtitle}</p>
        </div>
        <button
          aria-label="Log out"
          onClick={S.logout}
          className={`mt-2 rounded-full p-3 ${t.soft}`}
        >
          <LogOut className="h-5 w-5" />
        </button>
      </div>
      {children}
    </div>
  );
}
const Stat = ({ n, l, c = "text-primary" }: { n: ReactNode; l: string; c?: string }) => (
  <Card className="text-center">
    <div className={`text-3xl font-bold ${c}`}>{n}</div>
    <div className="text-sm font-medium text-muted-foreground">{l}</div>
  </Card>
);
const name = (st: St, id: string) => st.all.patients.find((p) => p.id === id)?.name ?? "Patient";
const byQueue = (a: S.Visit, b: S.Visit) =>
  Number(b.priority) - Number(a.priority) || a.scheduledTime.localeCompare(b.scheduledTime);

function CapacityLine({ d, date, st }: { d: S.Doctor; date: string; st: St }) {
  const c = S.getCapacity(d.id, date, st.all);
  return (
    <div>
      <div className="flex items-center justify-between gap-2">
        <span className="font-bold">
          {d.name} — {c.count} / {c.limit} patients{" "}
          {date === S.todayKey() ? "today" : `on ${S.fmtDate(date)}`}
        </span>
        {!c.available ? (
          <Pill tone="bad">Unavailable</Pill>
        ) : c.full ? (
          <Pill tone="bad">Full</Pill>
        ) : (
          <Pill tone="ok">{c.remaining} left</Pill>
        )}
      </div>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-secondary">
        <div
          className={`h-full ${c.full ? "bg-destructive" : "bg-primary"}`}
          style={{ width: `${Math.min(100, (c.count / c.limit) * 100)}%` }}
        />
      </div>
    </div>
  );
}

// ================= RECEPTIONIST =================
function ReceptionHome({ st, nav, pending }: P) {
  const today = S.todayKey();
  const appts = st.local.visits
    .filter((v) => v.date === today && v.status !== "completed" && v.status !== "cancelled")
    .sort(byQueue);
  const alerts = st.local.notifications.filter((n) => n.kind === "emergency").slice(0, 2);
  return (
    <>
      <Hero st={st} subtitle="Reception · front desk" />
      <div className="space-y-5 p-4">
        <StatusBanner st={st} pending={pending} onClick={() => nav({ name: "sync" })} />
        {alerts.map((n) => (
          <Card key={n.id} className="border-destructive">
            <div className="flex gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5 shrink-0" />
              <span className="font-semibold">{n.message}</span>
            </div>
          </Card>
        ))}
        <div className="grid grid-cols-3 gap-3">
          <Stat n={appts.length} l="Today's appts" />
          <Stat
            n={st.local.doctors.filter((d) => S.isDoctorAvailable(d, today)).length}
            l="Doctors in"
          />
          <Stat n={pending} l="Pending sync" c="text-warning" />
        </div>
        <H2>Quick actions</H2>
        <div className="grid grid-cols-3 gap-3">
          <button
            onClick={() => nav({ name: "register" })}
            className="rounded-2xl bg-reception p-4 font-bold text-reception-foreground"
          >
            <UserPlus className="mx-auto mb-2 h-6 w-6" />
            Register Patient
          </button>
          <button
            onClick={() => nav({ name: "book" })}
            className="rounded-2xl border border-border bg-card p-4 font-bold"
          >
            <CalendarPlus className="mx-auto mb-2 h-6 w-6" />
            Book Visit
          </button>
          <button
            onClick={() => nav({ name: "search" })}
            className="rounded-2xl border border-border bg-card p-4 font-bold"
          >
            <Search className="mx-auto mb-2 h-6 w-6" />
            Search Patient
          </button>
        </div>
        <H2>Doctors today</H2>
        <Card className="space-y-4">
          {st.local.doctors.map((d) => (
            <CapacityLine key={d.id} d={d} date={today} st={st} />
          ))}
        </Card>
        <H2>Today's appointments</H2>
        {appts.length ? (
          appts.map((v) => <AppointmentCard key={v.id} v={v} st={st} nav={nav} />)
        ) : (
          <Card className="text-center text-muted-foreground">No appointments left today.</Card>
        )}
      </div>
    </>
  );
}

function AppointmentCard({ v, st, nav }: { v: S.Visit; st: St; nav: P["nav"] }) {
  const [mode, setMode] = useState<"none" | "move">("none");
  const [date, setDate] = useState(S.addDays(v.date, 1));
  const isRec = st.user?.role === "receptionist";
  const act = (fn: () => void, ok: string) => {
    try {
      fn();
      toast.success(ok);
      setMode("none");
    } catch (e) {
      toast.error(errMsg(e));
    }
  };
  const actions =
    v.status === "scheduled" ? (
      isRec ? (
        <>
          <button className={ghostBtn} onClick={() => nav({ name: "history", id: v.patientId })}>
            History
          </button>
          <button className={ghostBtn} onClick={() => setMode(mode === "move" ? "none" : "move")}>
            <CalendarDays className="h-4 w-4" />
            Reschedule
          </button>
          <button
            className={ghostBtn}
            onClick={() => act(() => S.cancelAppointment(v.id), "Appointment cancelled")}
          >
            <XCircle className="h-4 w-4" />
            Cancel
          </button>
          {mode === "move" && (
            <div className="flex w-full gap-2">
              <input
                type="date"
                className={inputCls}
                value={date}
                min={S.todayKey()}
                onChange={(e) => setDate(e.target.value)}
              />
              <button
                className={ghostBtn}
                onClick={() => act(() => S.rescheduleAppointment(v.id, date), "Appointment moved")}
              >
                Move
              </button>
            </div>
          )}
        </>
      ) : (
        <>
          <button className={ghostBtn} onClick={() => nav({ name: "history", id: v.patientId })}>
            Patient
          </button>
          <button
            className={ghostBtn}
            onClick={() => act(() => S.markCompleted(v.id), "Visit marked completed")}
          >
            <CheckCircle2 className="h-4 w-4" />
            Mark completed
          </button>
        </>
      )
    ) : undefined;
  return (
    <VisitCard
      v={v}
      st={st}
      title={`${name(st, v.patientId)}${v.status === "scheduled" && v.date === S.todayKey() ? ` · #${S.queuePosition(v, st.all)} in queue` : ""}`}
      actions={actions}
    />
  );
}

function BookScreen({ st, back, nav, patientId }: P & { patientId?: string }) {
  const [pid, setPid] = useState(patientId ?? "");
  const [q, setQ] = useState("");
  const [doctorId, setDoctorId] = useState(st.local.doctors[0]?.id ?? "");
  const [date, setDate] = useState(S.todayKey());
  const [symptoms, setSymptoms] = useState("");
  const [done, setDone] = useState<S.BookingResult | null>(null);
  const patient = st.local.patients.find((p) => p.id === pid);
  const doc = st.local.doctors.find((d) => d.id === doctorId);
  const cap = doc ? S.getCapacity(doc.id, date, st.all) : null;
  const matches = q.trim()
    ? st.local.patients
        .filter((p) => p.name.toLowerCase().includes(q.toLowerCase()) || p.phone.includes(q))
        .slice(0, 5)
    : [];
  if (done) {
    const v = st.all.visits.find((x) => x.id === done.visit.id) ?? done.visit;
    const n = st.all.notifications.find((x) => x.id === done.notification.id) ?? done.notification;
    return (
      <>
        <Header st={st} title="Booking confirmed" onBack={back} />
        <div className="space-y-4 p-4">
          <ConfirmationCard
            v={v}
            n={n}
            patientName={name(st, v.patientId)}
            offline={done.offline}
          />
          <button
            className={primaryBtn}
            onClick={() => {
              setDone(null);
              setPid("");
              setSymptoms("");
            }}
          >
            Book another
          </button>
          <button
            className={`${ghostBtn} w-full`}
            onClick={() => nav({ name: "history", id: v.patientId })}
          >
            Open patient history
          </button>
        </div>
      </>
    );
  }
  const submit = () => {
    try {
      const r = S.bookAppointment({
        patientId: pid,
        doctorId,
        date,
        symptoms: symptoms
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean),
      });
      setDone(r);
      if (r.offline)
        toast("Appointment saved offline. Confirmation will be sent when you are back online.");
      else toast.success(`Booked with ${r.visit.doctor} at ${r.visit.scheduledTime}`);
    } catch (e) {
      toast.error(errMsg(e));
    }
  };
  return (
    <>
      <Header st={st} title="Book Appointment" onBack={back} />
      <div className="space-y-4 p-4">
        {patient ? (
          <Card className="flex items-center justify-between">
            <div>
              <div className="font-bold">{patient.name}</div>
              <div className="text-sm text-muted-foreground">
                {patient.age} yrs · {patient.gender} · {patient.phone}
              </div>
            </div>
            {!patientId && (
              <button className={ghostBtn} onClick={() => setPid("")}>
                Change
              </button>
            )}
          </Card>
        ) : (
          <Field label="Patient">
            <input
              className={inputCls}
              placeholder="Search name or phone"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              maxLength={100}
            />
            <div className="mt-2 space-y-1">
              {matches.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setPid(p.id)}
                  className="block w-full rounded-xl border border-border bg-card px-4 py-2 text-left"
                >
                  <b>{p.name}</b> <span className="text-sm text-muted-foreground">· {p.phone}</span>
                </button>
              ))}
            </div>
            <button
              type="button"
              className="mt-2 text-sm font-semibold text-primary"
              onClick={() => nav({ name: "register" })}
            >
              + Register a new patient
            </button>
          </Field>
        )}
        <Field label="Doctor">
          <select
            className={inputCls}
            value={doctorId}
            onChange={(e) => setDoctorId(e.target.value)}
          >
            {st.local.doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} · {d.specialty}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Appointment date">
          <input
            type="date"
            className={inputCls}
            value={date}
            min={S.todayKey()}
            onChange={(e) => setDate(e.target.value)}
          />
        </Field>
        <Field label="Reason / symptoms (optional)">
          <input
            className={inputCls}
            value={symptoms}
            onChange={(e) => setSymptoms(e.target.value)}
            placeholder="Fever, cough"
            maxLength={300}
          />
        </Field>
        {doc && cap && (
          <Card className="space-y-2">
            <div className="text-xs font-semibold tracking-wider text-muted-foreground">
              BEFORE YOU CONFIRM
            </div>
            <div className="text-lg font-bold">{doc.name}</div>
            <div className="grid grid-cols-2 gap-1 text-sm">
              <span className="text-muted-foreground">Date</span>
              <span>{S.fmtDate(date)}</span>
              <span className="text-muted-foreground">Assigned time</span>
              <span>
                {cap.available && !cap.full ? S.previewNextTime(doc.id, date, st.all) : "—"}
              </span>
              <span className="text-muted-foreground">Appointments</span>
              <span>
                {cap.count} / {cap.limit}
              </span>
              <span className="text-muted-foreground">Available slots</span>
              <span className="font-bold">{cap.remaining}</span>
            </div>
            {!cap.available && (
              <p className="text-sm font-semibold text-destructive">
                {doc.name} is unavailable on this date
                {doc.emergencyReasons?.[date] ? ` (${doc.emergencyReasons[date]})` : ""}.
              </p>
            )}
            {cap.available && cap.full && (
              <p className="text-sm font-semibold text-destructive">{S.limitMessage(doc)}</p>
            )}
          </Card>
        )}
        <button
          className={primaryBtn}
          disabled={!pid || !cap || !cap.available || cap.full}
          onClick={submit}
        >
          <CheckCircle2 className="h-5 w-5" />
          Confirm booking
        </button>
        {!st.online && (
          <p className="text-center text-sm text-muted-foreground">
            You're offline — the booking will be checked and confirmed when you reconnect.
          </p>
        )}
      </div>
    </>
  );
}

function ConfirmationCard({
  v,
  n,
  patientName,
  offline,
}: {
  v: S.Visit;
  n?: S.Notification;
  patientName: string;
  offline?: boolean;
}) {
  return (
    <Card className="space-y-3 border-success">
      <div className="flex items-center gap-2 text-success">
        <CheckCircle2 className="h-6 w-6" />
        <span className="text-lg font-bold">
          {offline ? "Saved on this device" : "Appointment booked"}
        </span>
      </div>
      <div className="grid grid-cols-2 gap-1 text-sm">
        <span className="text-muted-foreground">Patient</span>
        <span className="font-semibold">{patientName}</span>
        <span className="text-muted-foreground">Doctor</span>
        <span>{v.doctor}</span>
        <span className="text-muted-foreground">Date</span>
        <span>{S.fmtDate(v.date)}</span>
        <span className="text-muted-foreground">Time</span>
        <span>{v.scheduledTime}</span>
        <span className="text-muted-foreground">Visit ID</span>
        <span className="truncate font-mono text-xs">{v.id}</span>
        <span className="text-muted-foreground">Booking</span>
        <span>
          {v.bookingStatus === "awaiting_sync"
            ? "Awaiting sync"
            : v.bookingStatus === "rejected"
              ? "Rejected"
              : v.bookingStatus === "over_limit"
                ? "Over limit – needs attention"
                : "Accepted"}
        </span>
        <span className="text-muted-foreground">Confirmation</span>
        <span>{n ? <NotifStatus s={n.status} /> : "—"}</span>
      </div>
      {n && <p className="rounded-xl bg-secondary p-3 text-sm">{n.message}</p>}
    </Card>
  );
}

function DoctorsScreen({ st, back }: P) {
  const today = S.todayKey();
  const [limits, setLimits] = useState<Record<string, string>>({});
  return (
    <>
      <Header st={st} title="Doctors & Settings" onBack={back} />
      <div className="space-y-4 p-4">
        {st.local.doctors.map((d) => {
          const todays = st.all.visits
            .filter((v) => v.doctorId === d.id && v.date === today && v.status !== "cancelled")
            .sort(byQueue);
          const upcomingOff = d.unavailableDates.filter((x) => x >= today);
          return (
            <Card key={d.id} className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold">{d.name}</div>
                  <div className="text-sm text-muted-foreground">{d.specialty}</div>
                </div>
                {S.isDoctorAvailable(d, today) ? (
                  <Pill tone="ok">Available today</Pill>
                ) : (
                  <Pill tone="bad">Unavailable today</Pill>
                )}
              </div>
              <CapacityLine d={d} date={today} st={st} />
              {upcomingOff.length > 0 && (
                <p className="text-sm text-destructive">
                  Unavailable: {upcomingOff.map(S.fmtDate).join(", ")}
                </p>
              )}
              <div className="flex items-end gap-2">
                <Field label="Daily limit">
                  <input
                    inputMode="numeric"
                    className={inputCls}
                    value={limits[d.id] ?? String(d.dailyLimit)}
                    onChange={(e) => setLimits({ ...limits, [d.id]: e.target.value })}
                    maxLength={3}
                  />
                </Field>
                <button
                  className={`${ghostBtn} h-12`}
                  onClick={() => {
                    try {
                      S.setDailyLimit(d.id, Number(limits[d.id] ?? d.dailyLimit));
                      toast.success(`Daily limit saved for ${d.name}`);
                    } catch (e) {
                      toast.error(errMsg(e));
                    }
                  }}
                >
                  Save
                </button>
              </div>
              <div>
                <div className="mb-1 text-xs font-semibold tracking-wider text-muted-foreground">
                  TODAY'S SCHEDULE
                </div>
                {todays.length ? (
                  <ul className="space-y-1 text-sm">
                    {todays.map((v) => (
                      <li key={v.id} className="flex flex-wrap items-center gap-2">
                        <b>{v.scheduledTime}</b>
                        {name(st, v.patientId)}
                        <VisitStatusPill v={v} />
                        {v.priority && <PriorityTag v={v} />}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-sm text-muted-foreground">No appointments today.</p>
                )}
              </div>
            </Card>
          );
        })}
      </div>
    </>
  );
}

// ================= DOCTOR =================
function DoctorHome({ st, nav, pending }: P) {
  const today = S.todayKey();
  const me = st.local.doctors.find((d) => d.id === st.user!.doctorId);
  const todays = st.local.visits
    .filter((v) => v.date === today && v.status === "scheduled")
    .sort(byQueue);
  const done = st.local.visits.filter((v) => v.date === today && v.status === "completed");
  const prio = todays.filter((v) => v.priority);
  const cap = me ? S.getCapacity(me.id, today, st.all) : null;
  return (
    <>
      <Hero st={st} subtitle={`Doctor · ${me?.specialty ?? ""}`} />
      <div className="space-y-5 p-4">
        <StatusBanner st={st} pending={pending} onClick={() => nav({ name: "sync" })} />
        {me && !S.isDoctorAvailable(me, today) && (
          <Card className="border-destructive text-destructive">
            <b>You are marked unavailable today.</b> Your patients have been moved.
          </Card>
        )}
        <div className="grid grid-cols-3 gap-3">
          <Stat n={cap ? `${cap.count}/${cap.limit}` : "—"} l="Today / limit" />
          <Stat n={prio.length} l="Priority" c="text-priority" />
          <Stat n={done.length} l="Completed" c="text-success" />
        </div>
        {prio.length > 0 && (
          <>
            <H2>Priority patients</H2>
            {prio.map((v) => (
              <AppointmentCard key={v.id} v={v} st={st} nav={nav} />
            ))}
          </>
        )}
        <H2>Today's queue</H2>
        {todays.filter((v) => !v.priority).length ? (
          todays
            .filter((v) => !v.priority)
            .map((v) => <AppointmentCard key={v.id} v={v} st={st} nav={nav} />)
        ) : (
          <Card className="text-center text-muted-foreground">
            {prio.length ? "No other appointments today." : "No appointments waiting today."}
          </Card>
        )}
        {done.length > 0 && (
          <>
            <H2>Completed today</H2>
            {done.map((v) => (
              <VisitCard key={v.id} v={v} st={st} title={name(st, v.patientId)} />
            ))}
          </>
        )}
      </div>
    </>
  );
}

function ScheduleScreen({ st, back, nav }: P) {
  const today = S.todayKey();
  const [tabName, setTab] = useState<"upcoming" | "completed" | "moved">("upcoming");
  const vs = st.local.visits;
  const list =
    tabName === "upcoming"
      ? vs
          .filter((v) => v.date > today && v.status === "scheduled")
          .sort((a, b) => a.date.localeCompare(b.date) || byQueue(a, b))
      : tabName === "completed"
        ? vs
            .filter((v) => v.status === "completed")
            .sort((a, b) => b.visitDate.localeCompare(a.visitDate))
        : vs.filter((v) => v.rescheduledFrom).sort((a, b) => a.date.localeCompare(b.date));
  return (
    <>
      <Header st={st} title="My Schedule" onBack={back} />
      <div className="space-y-4 p-4">
        <div className="grid grid-cols-3 gap-2 rounded-xl bg-secondary p-1">
          {(["upcoming", "completed", "moved"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-lg py-2 text-sm font-semibold capitalize ${tabName === t ? "bg-card" : "text-muted-foreground"}`}
            >
              {t === "moved" ? "Moved" : t}
            </button>
          ))}
        </div>
        {list.map((v) =>
          v.status === "scheduled" ? (
            <AppointmentCard key={v.id} v={v} st={st} nav={nav} />
          ) : (
            <VisitCard key={v.id} v={v} st={st} title={name(st, v.patientId)} />
          ),
        )}
        {!list.length && (
          <Card className="text-center text-muted-foreground">Nothing here yet.</Card>
        )}
      </div>
    </>
  );
}

function EmergencyScreen({ st, back }: P) {
  const me = st.local.doctors.find((d) => d.id === st.user!.doctorId);
  const [date, setDate] = useState(S.todayKey());
  const [reason, setReason] = useState("");
  const [open, setOpen] = useState(false);
  if (!me) return null;
  const affected = S.affectedByEmergency(me.id, date, st.all).length;
  const confirm = () => {
    try {
      const ev = S.handleDoctorEmergency(me.id, date, reason.trim());
      toast.success(`Marked unavailable. ${ev.length} appointment(s) moved.`);
      setReason("");
    } catch (e) {
      toast.error(errMsg(e));
    }
  };
  return (
    <>
      <Header st={st} title="Emergency Settings" onBack={back} />
      <div className="space-y-4 p-4">
        <Card className="space-y-4">
          <div className="flex items-center gap-2 font-bold text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Mark unavailable (emergency)
          </div>
          <Field label="Unavailable date">
            <input
              type="date"
              className={inputCls}
              value={date}
              min={S.todayKey()}
              onChange={(e) => setDate(e.target.value)}
            />
          </Field>
          <Field label="Emergency reason">
            <input
              className={inputCls}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Family emergency"
              maxLength={200}
            />
          </Field>
          <p className="text-sm text-muted-foreground">
            {affected} scheduled appointment(s) on this date. They'll move to your next available
            days as priority patients.
          </p>
          <button
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-destructive py-3.5 font-bold text-destructive-foreground disabled:opacity-50"
            disabled={!reason.trim() || !S.isDoctorAvailable(me, date)}
            onClick={() => setOpen(true)}
          >
            Mark unavailable
          </button>
          {!S.isDoctorAvailable(me, date) && (
            <p className="text-sm text-destructive">
              You're already marked unavailable on this date.
            </p>
          )}
        </Card>
        <Card>
          <div className="mb-2 font-bold">My unavailable dates</div>
          {me.unavailableDates.length ? (
            <ul className="space-y-1 text-sm">
              {[...me.unavailableDates].reverse().map((d) => (
                <li key={d}>
                  {S.fmtDate(d)}{" "}
                  {me.emergencyReasons?.[d] && (
                    <span className="text-muted-foreground">· {me.emergencyReasons[d]}</span>
                  )}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-muted-foreground">None.</p>
          )}
        </Card>
        <Card>
          <div className="font-bold">Daily limit: {me.dailyLimit} patients</div>
          <p className="text-sm text-muted-foreground">
            Ask the front desk to change your daily limit.
          </p>
        </Card>
      </div>
      <AlertDialog open={open} onOpenChange={setOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Mark unavailable?</AlertDialogTitle>
            <AlertDialogDescription>
              Marking {me.name} unavailable on {S.fmtDate(date)} will affect {affected} scheduled
              appointment{affected === 1 ? "" : "s"}. Continue?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirm}>Continue</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

// ================= SHARED =================
function NotificationsScreen({ st, back }: P) {
  useEffect(() => {
    const t = setTimeout(() => S.markAllRead(), 800);
    return () => clearTimeout(t);
  }, []);
  const label: Record<S.NotificationKind, string> = {
    booking: "Booking confirmation",
    rescheduled: "Rescheduled",
    rejected: "Booking rejected",
    new_appointment: "New appointment",
    emergency: "Doctor emergency",
    cancelled: "Cancelled",
    over_limit: "Over limit",
  };
  const ns = st.local.notifications;
  return (
    <>
      <Header st={st} title="Notifications" onBack={back} />
      <div className="space-y-3 p-4">
        {ns.map((n) => (
          <Card key={n.id} className={n.readBy.includes(st.user!.username) ? "" : "border-primary"}>
            <div className="flex items-start justify-between gap-2">
              <div className="font-bold">{label[n.kind]}</div>
              <NotifStatus s={n.status} />
            </div>
            <p className="mt-1 text-sm">{n.message}</p>
            <div className="mt-2 grid grid-cols-2 gap-x-2 text-xs text-muted-foreground">
              {n.patientId && <span>Patient: {n.patientName}</span>}
              <span>Doctor: {n.doctorName}</span>
              {n.time && (
                <span>
                  Appt: {S.fmtDate(n.date)} {n.time}
                </span>
              )}
              <span>{n.audience === "patient" ? `To patient · ${n.channel}` : "Internal"}</span>
              <span className="col-span-2">
                Created {new Date(n.createdAt).toLocaleString("en-GB")}
              </span>
            </div>
          </Card>
        ))}
        {!ns.length && (
          <Card className="text-center text-muted-foreground">No notifications yet.</Card>
        )}
      </div>
    </>
  );
}

function PatientRow({
  p,
  visits,
  onClick,
}: {
  p: S.Patient;
  visits: S.Visit[];
  onClick: () => void;
}) {
  const vs = visits
    .filter((v) => v.patientId === p.id)
    .sort((a, b) => b.visitDate.localeCompare(a.visitDate));
  const last = vs.find((v) => v.status === "completed");
  return (
    <button onClick={onClick} className="block w-full text-left">
      <Card className="flex items-center gap-3">
        <div className="grid h-12 w-12 place-items-center rounded-full bg-secondary font-bold text-secondary-foreground">
          {initials(p.name)}
        </div>
        <div className="min-w-0 flex-1">
          <div className="font-bold">{p.name}</div>
          <div className="text-sm text-muted-foreground">
            {p.age} yrs · Total visits: {vs.length}
          </div>
          {last && (
            <div className="truncate text-sm text-muted-foreground">
              Last:{" "}
              {new Date(last.visitDate).toLocaleDateString("en-GB", {
                day: "2-digit",
                month: "short",
              })}{" "}
              · {last.symptoms.join(", ")}
            </div>
          )}
        </div>
        <Badge
          status={
            p.syncStatus === "pending" || vs.some((v) => v.syncStatus === "pending")
              ? "pending"
              : "synced"
          }
        />
      </Card>
    </button>
  );
}

function SearchScreen({ st, nav, back }: P) {
  const [q, setQ] = useState("");
  const res = useMemo(() => {
    const t = q.trim().toLowerCase();
    return st.local.patients
      .filter(
        (p) =>
          !t ||
          p.name.toLowerCase().includes(t) ||
          p.phone.includes(t) ||
          p.id.toLowerCase().includes(t),
      )
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [q, st.local.patients]);
  const isDoc = st.user?.role === "doctor";
  return (
    <>
      <Header
        st={st}
        title={isDoc ? "My Patients" : "Search Patient"}
        onBack={back}
        right={
          !isDoc ? (
            <button
              aria-label="Register patient"
              onClick={() => nav({ name: "register" })}
              className="p-2"
            >
              <UserPlus className="h-5 w-5" />
            </button>
          ) : undefined
        }
      />
      <div className="space-y-3 p-4">
        <div className="relative">
          <Search className="absolute left-4 top-3.5 h-5 w-5 text-muted-foreground" />
          <input
            autoFocus
            className={inputCls + " pl-12"}
            placeholder="Name, phone or patient ID"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            maxLength={100}
          />
        </div>
        <p className="text-sm text-muted-foreground">
          {isDoc
            ? "Only patients assigned to you are shown."
            : "Searching device storage — works offline."}
        </p>
        {res.map((p) => (
          <PatientRow
            key={p.id}
            p={p}
            visits={st.local.visits}
            onClick={() => nav({ name: "history", id: p.id })}
          />
        ))}
        {!res.length && (
          <Card className="text-center text-muted-foreground">No patients found.</Card>
        )}
      </div>
    </>
  );
}

function History({ st, nav, back, id }: P & { id: string }) {
  const [showAll, setShowAll] = useState(false);
  let p: S.Patient | null = null;
  let denied = "";
  try {
    p = S.getPatientRecord(id);
  } catch (e) {
    denied = errMsg(e);
  }
  if (!p)
    return (
      <>
        <Header st={st} title="Patient History" onBack={back} />
        <p className="p-4">{denied || "Patient not found."}</p>
      </>
    );
  const local = st.local.visits.filter((v) => v.patientId === id);
  const localIds = new Set(local.map((v) => v.id));
  const scope = (v: S.Visit) =>
    st.user?.role === "receptionist" || v.doctorId === st.user?.doctorId;
  const archived = st.online
    ? st.server.visits.filter((v) => v.patientId === id && !localIds.has(v.id) && scope(v))
    : [];
  const visits = [...local, ...(showAll ? archived : [])].sort((a, b) =>
    b.visitDate.localeCompare(a.visitDate),
  );
  const status: S.SyncStatus =
    p.syncStatus === "pending" || local.some((v) => v.syncStatus === "pending")
      ? "pending"
      : "synced";
  const isRec = st.user?.role === "receptionist";
  return (
    <>
      <Header
        st={st}
        title="Patient History"
        onBack={back}
        right={
          <button
            aria-label="Edit patient"
            onClick={() => nav({ name: "edit", id })}
            className="p-2"
          >
            <Pencil className="h-5 w-5" />
          </button>
        }
      />
      <div className="space-y-4 p-4">
        <Card className="flex gap-4">
          <div className="grid h-16 w-16 shrink-0 place-items-center rounded-full bg-secondary text-xl font-bold text-secondary-foreground">
            {initials(p.name)}
          </div>
          <div className="flex-1">
            <div className="flex items-start justify-between gap-2">
              <h2 className="text-xl font-bold">{p.name}</h2>
              <Badge status={status} />
            </div>
            <p className="text-sm text-muted-foreground">
              {p.age} yrs · {p.gender} · {p.phone}
            </p>
            <p className="text-sm text-muted-foreground">{p.address}</p>
            <span className="mt-2 inline-block rounded-full bg-secondary px-3 py-1 text-sm font-semibold">
              Total visits: {local.length + archived.length}
            </span>
          </div>
        </Card>
        {isRec ? (
          <button className={primaryBtn} onClick={() => nav({ name: "book", patientId: id })}>
            <CalendarPlus className="h-5 w-5" /> Book Appointment
          </button>
        ) : (
          <button className={primaryBtn} onClick={() => nav({ name: "visit", id })}>
            <PlusCircle className="h-5 w-5" /> Add New Visit
          </button>
        )}
        <h3 className="text-lg font-bold">Visit timeline — this device ({local.length})</h3>
        {visits.map((v) => (
          <div key={v.id} className={localIds.has(v.id) ? "" : "opacity-80"}>
            {!localIds.has(v.id) && (
              <p className="mb-1 text-xs font-semibold text-muted-foreground">FROM MAIN DATABASE</p>
            )}
            {v.status === "scheduled" ? (
              <AppointmentCard v={v} st={st} nav={nav} />
            ) : (
              <VisitCard v={v} st={st} />
            )}
          </div>
        ))}
        {!local.length && (
          <Card className="text-center text-muted-foreground">
            No visits on this device in the last month.
          </Card>
        )}
        {archived.length > 0 && !showAll && (
          <button
            onClick={() => setShowAll(true)}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-border py-3 font-semibold"
          >
            <Database className="h-4 w-4" />
            Load {archived.length} older visits from main database
          </button>
        )}
        {!st.online && (
          <p className="text-center text-sm text-muted-foreground">
            Offline — older history in the main database will be available when connected.
          </p>
        )}
      </div>
    </>
  );
}

function PatientForm({ st, back, id, onDone }: P & { id?: string; onDone: (id: string) => void }) {
  const ex = id ? st.local.patients.find((p) => p.id === id) : undefined;
  const [f, setF] = useState({
    name: ex?.name ?? "",
    age: ex ? String(ex.age) : "",
    gender: ex?.gender ?? "Male",
    phone: ex?.phone ?? "",
    address: ex?.address ?? "",
  });
  const [err, setErr] = useState("");
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) =>
    setF({ ...f, [k]: e.target.value });
  const submit = () => {
    const age = Number(f.age);
    if (!f.name.trim()) return setErr("Name is required");
    if (!Number.isInteger(age) || age < 0 || age > 130) return setErr("Enter a valid age");
    if (!/^[0-9+ -]{6,15}$/.test(f.phone)) return setErr("Enter a valid contact number");
    try {
      const pid = ex?.id ?? S.newId("P");
      S.savePatient({
        id: pid,
        name: f.name.trim(),
        age,
        gender: f.gender,
        phone: f.phone.trim(),
        address: f.address.trim(),
      });
      toast.success(
        ex ? "Patient updated" : `${f.name.trim()} registered — now book an appointment`,
      );
      onDone(pid);
    } catch (e) {
      setErr(errMsg(e));
    }
  };
  return (
    <>
      <Header st={st} title={ex ? "Edit Patient" : "Register Patient"} onBack={back} />
      <form
        className="space-y-4 p-4"
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <Field label="Patient name">
          <input className={inputCls} value={f.name} onChange={set("name")} maxLength={100} />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Age">
            <input
              inputMode="numeric"
              className={inputCls}
              value={f.age}
              onChange={set("age")}
              maxLength={3}
            />
          </Field>
          <Field label="Gender">
            <select className={inputCls} value={f.gender} onChange={set("gender")}>
              <option>Male</option>
              <option>Female</option>
              <option>Other</option>
            </select>
          </Field>
        </div>
        <Field label="Contact number">
          <input
            inputMode="tel"
            className={inputCls}
            value={f.phone}
            onChange={set("phone")}
            maxLength={15}
          />
        </Field>
        <Field label="Address">
          <input className={inputCls} value={f.address} onChange={set("address")} maxLength={200} />
        </Field>
        {err && <p className="text-sm text-destructive">{err}</p>}
        <button className={primaryBtn}>{ex ? "Save Changes" : "Save & book appointment"}</button>
        <p className="text-center text-sm text-muted-foreground">
          Saved to this device first
          {st.online ? ", then synced automatically." : " — will sync when internet returns."}
        </p>
      </form>
    </>
  );
}

function VisitForm({ st, back, id }: P & { id: string }) {
  const p = st.local.patients.find((x) => x.id === id);
  const [f, setF] = useState({ symptoms: "", diagnosis: "", treatment: "" });
  const [err, setErr] = useState("");
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) =>
    setF({ ...f, [k]: e.target.value });
  return (
    <>
      <Header st={st} title="Add New Visit" onBack={back} />
      <form
        className="space-y-4 p-4"
        onSubmit={(e) => {
          e.preventDefault();
          const sym = f.symptoms
            .split(",")
            .map((s) => s.trim())
            .filter(Boolean);
          if (!sym.length) return setErr("Add at least one symptom");
          try {
            const v = S.saveVisit({
              id: S.newId("V"),
              patientId: id,
              visitDate: new Date().toISOString(),
              symptoms: sym,
              diagnosis: f.diagnosis.trim(),
              treatment: f.treatment.trim(),
              doctor: st.user!.name,
              doctorId: st.user!.doctorId ?? "",
              status: "completed",
            });
            toast.success(`Visit saved for ${p?.name} at ${v.scheduledTime}`);
            back();
          } catch (ex) {
            setErr(errMsg(ex));
          }
        }}
      >
        <Card>
          <div className="font-bold">{p?.name}</div>
          <div className="text-sm text-muted-foreground">
            {new Date().toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "long",
              year: "numeric",
            })}
          </div>
        </Card>
        <Field label="Symptoms (comma separated)">
          <input
            autoFocus
            className={inputCls}
            value={f.symptoms}
            onChange={set("symptoms")}
            placeholder="Fever, cough, weakness"
            maxLength={300}
          />
        </Field>
        <Field label="Diagnosis">
          <input
            className={inputCls}
            value={f.diagnosis}
            onChange={set("diagnosis")}
            maxLength={200}
          />
        </Field>
        <Field label="Treatment">
          <textarea
            className={inputCls}
            rows={3}
            value={f.treatment}
            onChange={set("treatment")}
            maxLength={300}
          />
        </Field>
        {err && <p className="text-sm text-destructive">{err}</p>}
        <button className={primaryBtn}>Save Visit</button>
      </form>
    </>
  );
}

function SyncScreen({ st, back, pending }: P) {
  const [msg, setMsg] = useState("");
  const synced =
    st.all.patients.filter((p) => p.syncStatus === "synced").length +
    st.all.visits.filter((v) => v.syncStatus === "synced").length;
  const forced = S.isForcedOffline();
  const queue = [
    ...st.all.patients
      .filter((p) => p.syncStatus === "pending")
      .map((p) => ({ id: p.id, l: `Patient · ${p.name}` })),
    ...st.all.visits
      .filter((v) => v.syncStatus === "pending")
      .map((v) => ({
        id: v.id,
        l: `${v.status === "scheduled" ? "Appointment" : "Visit"} · ${name(st, v.patientId)} · ${S.fmtDate(v.date)} ${v.scheduledTime}`,
      })),
    ...st.all.doctors
      .filter((d) => d.syncStatus === "pending")
      .map((d) => ({ id: d.id, l: `Doctor settings · ${d.name}` })),
  ];
  return (
    <>
      <Header st={st} title="Synchronization" onBack={back} />
      <div className="space-y-4 p-4">
        <StatusBanner st={st} pending={pending} />
        <div className="grid grid-cols-2 gap-3">
          <Stat n={pending} l="Pending" c="text-warning" />
          <Stat n={synced} l="Synced" />
        </div>
        <button
          disabled={!st.online || st.syncing || !pending}
          className={primaryBtn}
          onClick={async () => {
            const r = await S.syncNow();
            if (r) setMsg(`✓ ${r.uploaded} records uploaded`);
          }}
        >
          <RefreshCw className={`h-5 w-5 ${st.syncing ? "animate-spin" : ""}`} />{" "}
          {st.syncing ? "Synchronizing…" : "Sync Now"}
        </button>
        {(msg || st.last) && (
          <p className="text-center font-semibold text-success">
            {msg ||
              `✓ ${st.last!.uploaded} records uploaded at ${new Date(st.last!.at).toLocaleTimeString()}`}
          </p>
        )}
        <Card>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {forced ? <WifiOff className="h-5 w-5" /> : <Wifi className="h-5 w-5" />}
              <div>
                <div className="font-bold">Simulate offline</div>
                <div className="text-sm text-muted-foreground">
                  For demo: cut the connection to the main database
                </div>
              </div>
            </div>
            <button
              role="switch"
              aria-checked={forced}
              aria-label="Simulate offline"
              onClick={() => S.setForcedOffline(!forced)}
              className={`relative h-7 w-12 rounded-full transition ${forced ? "bg-destructive" : "bg-secondary"}`}
            >
              <span
                className={`absolute top-1 h-5 w-5 rounded-full bg-card transition-all ${forced ? "left-6" : "left-1"}`}
              />
            </button>
          </div>
        </Card>
        {queue.length > 0 && (
          <Card>
            <div className="mb-2 text-xs font-semibold tracking-wider text-muted-foreground">
              WAITING FOR SYNCHRONIZATION
            </div>
            <ul className="space-y-1 text-sm">
              {queue.map((q) => (
                <li key={q.id}>
                  <ClipboardList className="mr-1 inline h-3.5 w-3.5" />
                  {q.l}
                </li>
              ))}
            </ul>
          </Card>
        )}
        <Card>
          <div className="mb-2 flex items-center gap-2 font-bold">
            <Database className="h-4 w-4" /> Main database
          </div>
          <p className="text-sm text-muted-foreground">
            {st.server.patients.length} patients · {st.server.visits.length} visits ·{" "}
            {st.server.notifications.length} notifications
          </p>
          <div className="mt-3 flex items-center gap-2 font-bold">
            <Trash2 className="h-4 w-4" /> Device retention
          </div>
          <p className="text-sm text-muted-foreground">
            Visits older than {S.RETENTION_DAYS} days are removed from this device — only after they
            are synced. Device holds {st.all.visits.length} visits.
          </p>
        </Card>
      </div>
    </>
  );
}
