// Offline-first store: "local" = device storage, "server" = simulated main database.
// All business rules (roles, daily limits, time slots, emergencies, notifications, sync) live here.
export type SyncStatus = "pending" | "synced";
export type Role = "doctor" | "receptionist";
export type VisitStatus = "scheduled" | "completed" | "rescheduled" | "cancelled";
export type BookingStatus = "accepted" | "awaiting_sync" | "rejected" | "over_limit";

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: string;
  phone: string;
  address: string;
  createdAt: string;
  updatedAt: string;
  updatedBy: string;
  syncStatus: SyncStatus;
}
export interface RescheduleEntry {
  from: string;
  to: string;
  reason: string;
  at: string;
}
export interface Visit {
  id: string;
  patientId: string;
  visitDate: string;
  symptoms: string[];
  diagnosis: string;
  treatment: string;
  doctor: string;
  createdAt: string;
  updatedAt: string;
  syncStatus: SyncStatus;
  doctorId: string;
  status: VisitStatus;
  priority: boolean;
  scheduledTime: string; // HH:mm
  date: string; // YYYY-MM-DD (appointment day)
  originalDate?: string;
  rescheduledFrom?: string;
  rescheduleReason?: string;
  rescheduleHistory?: RescheduleEntry[];
  bookingStatus?: BookingStatus;
  bookingNote?: string;
}
export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  dailyLimit: number;
  unavailableDates: string[];
  emergencyReasons?: Record<string, string>;
  updatedAt: string;
  syncStatus: SyncStatus;
}
export type NotificationKind =
  | "booking"
  | "rescheduled"
  | "rejected"
  | "new_appointment"
  | "emergency"
  | "cancelled"
  | "over_limit";
export type NotificationStatus = "queued" | "sent" | "failed";
export type Audience = "patient" | "doctor" | "reception";
export interface Notification {
  id: string;
  key: string;
  patientId: string;
  visitId: string;
  doctorId: string;
  doctorName: string;
  patientName: string;
  date: string;
  time: string;
  kind: NotificationKind;
  channel: string;
  status: NotificationStatus;
  createdAt: string;
  updatedAt: string;
  message: string;
  audience: Audience;
  readBy: string[];
  syncStatus: SyncStatus;
}
interface DB {
  patients: Patient[];
  visits: Visit[];
  doctors: Doctor[];
  notifications: Notification[];
}
export interface User {
  username: string;
  name: string;
  role: Role;
  doctorId?: string;
}

const LOCAL = "clinic.local.v1",
  SERVER = "clinic.server.v1",
  USER = "clinic.user.v1",
  NET = "clinic.forceOffline.v1",
  DEVICE = "clinic.device.v1";
export const RETENTION_DAYS = 30;
export const CLINIC_CONFIG = {
  startTime: "09:00",
  slotMinutes: 15,
  defaultDailyLimit: 20,
  minLimit: 1,
  maxLimit: 100,
};

export class ClinicError extends Error {
  constructor(
    public code: "FORBIDDEN" | "LIMIT" | "UNAVAILABLE" | "INVALID" | "NOT_FOUND",
    msg: string,
  ) {
    super(msg);
  }
}

const listeners = new Set<() => void>();
export const subscribe = (fn: () => void) => {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
};
const emit = () => listeners.forEach((l) => l());
const notifyListeners = new Set<(n: Notification) => void>();
export const onNotification = (fn: (n: Notification) => void) => {
  notifyListeners.add(fn);
  return () => {
    notifyListeners.delete(fn);
  };
};

// ---------- dates ----------
export const toKey = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
export const todayKey = () => toKey(new Date());
export const addDays = (key: string, n: number) => {
  const [y, m, d] = key.split("-").map(Number);
  return toKey(new Date(y!, m! - 1, d! + n));
};
const keyToDate = (key: string, time = "00:00") => {
  const [y, m, d] = key.split("-").map(Number);
  const [h, mi] = time.split(":").map(Number);
  return new Date(y!, m! - 1, d!, h || 0, mi || 0);
};
export const fmtDate = (key: string) =>
  keyToDate(key).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
export const fmtDMY = (key: string) => {
  const [y, m, d] = key.split("-");
  return `${d}/${m}/${y}`;
};
const slotTime = (i: number) => {
  const [h, m] = CLINIC_CONFIG.startTime.split(":").map(Number);
  const t = h! * 60 + m! + i * CLINIC_CONFIG.slotMinutes;
  return `${String(Math.floor(t / 60)).padStart(2, "0")}:${String(t % 60).padStart(2, "0")}`;
};

// ---------- storage + backward-compatible normalisation ----------
function normVisit(
  v: Partial<Visit> & { id: string; visitDate: string },
  doctors: Doctor[],
): Visit {
  const d = new Date(v.visitDate);
  const doc = doctors.find((x) => x.id === v.doctorId) ?? doctors.find((x) => x.name === v.doctor);
  return {
    symptoms: [],
    diagnosis: "",
    treatment: "",
    doctor: doc?.name ?? "",
    createdAt: v.visitDate,
    updatedAt: v.visitDate,
    syncStatus: "synced",
    ...v,
    doctorId: v.doctorId ?? doc?.id ?? "",
    status: v.status ?? "completed",
    priority: v.priority ?? false,
    date: v.date ?? toKey(d),
    scheduledTime:
      v.scheduledTime ??
      `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`,
  } as Visit;
}
function normDoctor(d: Partial<Doctor> & { id: string; name: string }): Doctor {
  return {
    specialty: "General Medicine",
    updatedAt: new Date(0).toISOString(),
    syncStatus: "synced",
    ...d,
    dailyLimit: d.dailyLimit ?? CLINIC_CONFIG.defaultDailyLimit,
    unavailableDates: d.unavailableDates ?? [],
  } as Doctor;
}
const read = (k: string): DB => {
  const raw = JSON.parse(localStorage.getItem(k) || "{}") as Partial<DB>;
  const doctors = (raw.doctors ?? []).map(normDoctor);
  return {
    patients: raw.patients ?? [],
    doctors,
    visits: (raw.visits ?? []).map((v) => normVisit(v, doctors)),
    notifications: raw.notifications ?? [],
  };
};
const write = (k: string, db: DB) => {
  localStorage.setItem(k, JSON.stringify(db));
};

const daysAgo = (n: number) => {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString();
};
function deviceId() {
  let id = localStorage.getItem(DEVICE);
  if (!id) {
    id = "dev" + Math.random().toString(36).slice(2, 6);
    localStorage.setItem(DEVICE, id);
  }
  return id;
}
export const newId = (p: string) =>
  `${deviceId()}-${p}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`;
const nowIso = () => new Date().toISOString();

const SEED_DOCTORS = (): Doctor[] => [
  normDoctor({ id: "D1", name: "Dr. Meera Nair", specialty: "General Medicine", dailyLimit: 15 }),
  normDoctor({ id: "D2", name: "Dr. Arjun Rao", specialty: "Paediatrics", dailyLimit: 10 }),
];

export function ensureSeed() {
  if (localStorage.getItem(SERVER)) {
    // migrate older databases that pre-date doctors
    for (const k of [SERVER, LOCAL]) {
      const db = read(k);
      if (!db.doctors.length) {
        db.doctors = SEED_DOCTORS();
        db.visits = db.visits.map((v) => normVisit(v, db.doctors));
        write(k, db);
      }
    }
    return;
  }
  const doctors = SEED_DOCTORS();
  const mk = (
    id: string,
    name: string,
    age: number,
    gender: string,
    phone: string,
    address: string,
  ): Patient => ({
    id,
    name,
    age,
    gender,
    phone,
    address,
    createdAt: daysAgo(40),
    updatedAt: daysAgo(40),
    updatedBy: "doctor",
    syncStatus: "synced",
  });
  const v = (
    id: string,
    pid: string,
    d: number,
    symptoms: string[],
    diagnosis: string,
    treatment: string,
  ): Visit =>
    normVisit(
      {
        id,
        patientId: pid,
        visitDate: daysAgo(d),
        symptoms,
        diagnosis,
        treatment,
        doctor: "Dr. Meera Nair",
        doctorId: "D1",
        createdAt: daysAgo(d),
        updatedAt: daysAgo(d),
        syncStatus: "synced",
        status: "completed",
      },
      doctors,
    );
  const patients = [
    mk("P1001", "Ravi Kumar", 45, "Male", "9876543210", "Village Rampur"),
    mk("P1002", "Suresh Yadav", 32, "Male", "9123456780", "Village Sonpur"),
    mk("P1003", "Anita Devi", 28, "Female", "9988776655", "Village Rampur"),
    mk("P1004", "Lakshmi Bai", 61, "Female", "9090909090", "Village Kheri"),
    mk("P1005", "Kiran Patel", 7, "Male", "9811122233", "Village Sonpur"),
  ];
  const visits = [
    v("V001", "P1001", 45, ["Fever", "Headache"], "Viral fever", "Paracetamol"),
    v("V002", "P1001", 12, ["Cough", "Fever"], "Upper respiratory infection", "Cough syrup, rest"),
    v("V003", "P1001", 8, ["Cold", "Cough"], "Common cold", "Antihistamine"),
    v("V004", "P1002", 20, ["Cold"], "Common cold", "Steam inhalation"),
    v("V005", "P1003", 5, ["Back pain"], "Muscle strain", "Rest, pain relief"),
    v("V006", "P1004", 38, ["Joint pain"], "Arthritis", "Physiotherapy"),
    v("V007", "P1004", 15, ["Dizziness"], "Low BP", "ORS, follow-up"),
    v("V008", "P1003", 50, ["Fever"], "Malaria test negative", "Paracetamol"),
    v("V009", "P1002", 2, ["Headache"], "Tension headache", "Hydration"),
  ];
  // a few upcoming appointments relative to today so dashboards aren't empty
  const appt = (id: string, pid: string, docId: string, offset: number, i: number): Visit => {
    const date = addDays(todayKey(), offset);
    const t = slotTime(i);
    const doc = doctors.find((d) => d.id === docId)!;
    return normVisit(
      {
        id,
        patientId: pid,
        doctorId: docId,
        doctor: doc.name,
        date,
        scheduledTime: t,
        visitDate: keyToDate(date, t).toISOString(),
        symptoms: [],
        diagnosis: "",
        treatment: "",
        status: "scheduled",
        priority: false,
        createdAt: daysAgo(1),
        updatedAt: daysAgo(1),
        syncStatus: "synced",
        bookingStatus: "accepted",
      },
      doctors,
    );
  };
  visits.push(
    appt("A001", "P1001", "D1", 0, 0),
    appt("A002", "P1003", "D1", 0, 1),
    appt("A003", "P1004", "D1", 1, 0),
    appt("A004", "P1005", "D2", 0, 0),
  );
  write(SERVER, { patients, visits, doctors, notifications: [] });
  const cutoff = Date.now() - RETENTION_DAYS * 864e5;
  write(LOCAL, {
    patients,
    doctors,
    notifications: [],
    visits: visits.filter((x) => new Date(x.visitDate).getTime() >= cutoff),
  });
}

// ---------- connectivity ----------
export const isForcedOffline = () => localStorage.getItem(NET) === "1";
export const setForcedOffline = (b: boolean) => {
  localStorage.setItem(NET, b ? "1" : "0");
  emit();
  if (!b) void syncNow();
};
export const isOnline = () => navigator.onLine && !isForcedOffline();

// ---------- auth + roles ----------
interface Account extends User {
  pw: string;
}
const ACCOUNTS: Record<string, Account> = {
  reception: {
    username: "reception",
    name: "Priya Sharma",
    role: "receptionist",
    pw: "reception123",
  },
  nurse: { username: "nurse", name: "Nurse Priya Sharma", role: "receptionist", pw: "nurse123" },
  doctor: {
    username: "doctor",
    name: "Dr. Meera Nair",
    role: "doctor",
    doctorId: "D1",
    pw: "doctor123",
  },
  arjun: {
    username: "arjun",
    name: "Dr. Arjun Rao",
    role: "doctor",
    doctorId: "D2",
    pw: "arjun123",
  },
};
export const DEMO_ACCOUNTS = Object.values(ACCOUNTS)
  .filter((a) => a.username !== "nurse")
  .map(({ username, name, role, pw }) => ({ username, name, role, pw }));
export const getUser = (): User | null => {
  const u = JSON.parse(localStorage.getItem(USER) || "null") as
    (Omit<User, "role"> & { role: string }) | null;
  if (u && u.role === "nurse") return { ...u, role: "receptionist" }; // older sessions
  return u as User | null;
};
export function login(username: string, password: string): User | null {
  const u = ACCOUNTS[username.trim().toLowerCase()];
  if (!u || u.pw !== password) return null;
  const { pw: _pw, ...user } = u;
  localStorage.setItem(USER, JSON.stringify(user));
  emit();
  return user;
}
export const logout = () => {
  localStorage.removeItem(USER);
  emit();
};

function requireRole(...roles: Role[]): User {
  const u = getUser();
  if (!u) throw new ClinicError("FORBIDDEN", "Please sign in.");
  if (!roles.includes(u.role))
    throw new ClinicError("FORBIDDEN", `This action is not allowed for ${u.role}s.`);
  return u;
}
function requireDoctorScope(u: User, doctorId: string) {
  if (u.role === "doctor" && u.doctorId !== doctorId)
    throw new ClinicError("FORBIDDEN", "Doctors can only manage their own schedule.");
}
export const canAccessPatient = (u: User, patientId: string, db = read(LOCAL)) =>
  u.role === "receptionist" ||
  [...db.visits, ...read(SERVER).visits].some(
    (v) => v.patientId === patientId && v.doctorId === u.doctorId,
  );

// ---------- local reads ----------
export const getLocal = () => read(LOCAL);
export const getServer = () => read(SERVER);
/** Role-filtered view: doctors only see their own patients/visits. */
export function getScoped(u: User | null = getUser()): DB {
  const db = read(LOCAL);
  if (!u) return { patients: [], visits: [], doctors: [], notifications: [] };
  const notifications = notificationsFor(u, db.notifications);
  if (u.role === "receptionist") return { ...db, notifications };
  const visits = db.visits.filter((v) => v.doctorId === u.doctorId);
  const pids = new Set(
    [...visits, ...read(SERVER).visits.filter((v) => v.doctorId === u.doctorId)].map(
      (v) => v.patientId,
    ),
  );
  return {
    patients: db.patients.filter((p) => pids.has(p.id)),
    visits,
    doctors: db.doctors,
    notifications,
  };
}
export function getPatientRecord(patientId: string) {
  const u = requireRole("doctor", "receptionist");
  const db = read(LOCAL);
  if (!canAccessPatient(u, patientId, db))
    throw new ClinicError("FORBIDDEN", "This patient is not assigned to you.");
  return db.patients.find((p) => p.id === patientId) ?? null;
}
function notificationsFor(u: User, all: Notification[]) {
  return all
    .filter((n) =>
      u.role === "receptionist"
        ? n.audience !== "doctor"
        : n.doctorId === u.doctorId && n.audience !== "reception",
    )
    .sort((x, y) => y.createdAt.localeCompare(x.createdAt));
}
export const unreadCount = (u: User) =>
  notificationsFor(u, read(LOCAL).notifications).filter((n) => !n.readBy.includes(u.username))
    .length;
export function markAllRead() {
  const u = getUser();
  if (!u) return;
  const db = read(LOCAL);
  const mine = new Set(notificationsFor(u, db.notifications).map((n) => n.id));
  db.notifications = db.notifications.map((n) =>
    mine.has(n.id) && !n.readBy.includes(u.username)
      ? { ...n, readBy: [...n.readBy, u.username] }
      : n,
  );
  write(LOCAL, db);
  emit();
}

// ---------- capacity + availability ----------
const isActive = (v: Visit) => v.status === "scheduled" || v.status === "completed";
/** Union of local (incl. pending offline) and server visits, local copy wins. */
function allVisits(db: DB) {
  const m = new Map(read(SERVER).visits.map((v) => [v.id, v]));
  db.visits.forEach((v) => m.set(v.id, v));
  return [...m.values()];
}
export function countVisitsForDoctor(doctorId: string, date: string, db = read(LOCAL)) {
  return allVisits(db).filter((v) => v.doctorId === doctorId && v.date === date && isActive(v))
    .length;
}
export const isDoctorAvailable = (d: Doctor, date: string) => !d.unavailableDates.includes(date);
export function getCapacity(doctorId: string, date: string, db = read(LOCAL)) {
  const d = db.doctors.find((x) => x.id === doctorId);
  if (!d) throw new ClinicError("NOT_FOUND", "Doctor not found.");
  const count = countVisitsForDoctor(doctorId, date, db);
  return {
    doctor: d,
    count,
    limit: d.dailyLimit,
    remaining: Math.max(0, d.dailyLimit - count),
    available: isDoctorAvailable(d, date),
    full: count >= d.dailyLimit,
  };
}
export const limitMessage = (d: Doctor) =>
  `${d.name} has reached today's limit (${d.dailyLimit}). Choose another doctor or another day.`;

/** Recompute slot times: priority first, then queue order; completed visits keep their slot. */
function assignTimes(db: DB, doctorId: string, date: string) {
  const day = db.visits.filter((v) => v.doctorId === doctorId && v.date === date && isActive(v));
  const taken = new Set(day.filter((v) => v.status === "completed").map((v) => v.scheduledTime));
  const queue = day
    .filter((v) => v.status === "scheduled")
    .sort(
      (a, b) =>
        Number(b.priority) - Number(a.priority) ||
        (a.priority && b.priority
          ? (a.originalDate ?? "").localeCompare(b.originalDate ?? "") ||
            a.scheduledTime.localeCompare(b.scheduledTime)
          : 0) ||
        a.createdAt.localeCompare(b.createdAt),
    );
  let i = 0;
  const now = nowIso();
  for (const v of queue) {
    while (taken.has(slotTime(i))) i++;
    const t = slotTime(i++);
    if (v.scheduledTime !== t) {
      const idx = db.visits.findIndex((x) => x.id === v.id);
      db.visits[idx] = {
        ...v,
        scheduledTime: t,
        visitDate: keyToDate(date, t).toISOString(),
        updatedAt: now,
        syncStatus: "pending",
      };
    }
  }
}
export const previewNextTime = (doctorId: string, date: string, db = read(LOCAL)) => {
  const day = allVisits(db).filter(
    (v) => v.doctorId === doctorId && v.date === date && isActive(v),
  );
  const taken = new Set(day.map((v) => v.scheduledTime));
  let i = 0;
  while (taken.has(slotTime(i))) i++;
  return slotTime(i);
};
export const queuePosition = (v: Visit, db = read(LOCAL)) =>
  db.visits
    .filter((x) => x.doctorId === v.doctorId && x.date === v.date && x.status === "scheduled")
    .sort((a, b) => a.scheduledTime.localeCompare(b.scheduledTime))
    .findIndex((x) => x.id === v.id) + 1;

// ---------- local writes (always succeed offline) ----------
export function savePatient(
  p: Omit<Patient, "createdAt" | "updatedAt" | "syncStatus" | "updatedBy"> & Partial<Patient>,
) {
  const u = requireRole("receptionist", "doctor");
  const db = read(LOCAL);
  const now = nowIso();
  const existing = db.patients.find((x) => x.id === p.id);
  if (existing && !canAccessPatient(u, existing.id, db))
    throw new ClinicError("FORBIDDEN", "This patient is not assigned to you.");
  if (!existing && u.role !== "receptionist")
    throw new ClinicError("FORBIDDEN", "Only receptionists can register patients.");
  const rec: Patient = {
    ...existing,
    ...p,
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
    updatedBy: u.username,
    syncStatus: "pending",
  } as Patient;
  db.patients = existing
    ? db.patients.map((x) => (x.id === p.id ? rec : x))
    : [...db.patients, rec];
  write(LOCAL, db);
  emit();
  if (isOnline()) void syncNow();
  return rec;
}

type VisitInput = Omit<
  Visit,
  | "createdAt"
  | "updatedAt"
  | "syncStatus"
  | "doctorId"
  | "status"
  | "priority"
  | "scheduledTime"
  | "date"
> &
  Partial<Visit>;
/** Saves a visit. New active visits are checked against the doctor's daily limit (including offline pending ones). */
export function saveVisit(v: VisitInput) {
  const u = requireRole("receptionist", "doctor");
  const db = read(LOCAL);
  const now = nowIso();
  const doc =
    db.doctors.find((d) => d.id === v.doctorId) ??
    db.doctors.find((d) => d.name === v.doctor) ??
    (u.doctorId ? db.doctors.find((d) => d.id === u.doctorId) : undefined);
  if (!doc) throw new ClinicError("INVALID", "Choose a doctor.");
  requireDoctorScope(u, doc.id);
  const existing = db.visits.find((x) => x.id === v.id);
  const date = v.date ?? toKey(new Date(v.visitDate));
  const rec = normVisit(
    {
      ...existing,
      ...v,
      doctorId: doc.id,
      doctor: doc.name,
      date,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
      syncStatus: "pending",
      status: v.status ?? existing?.status ?? "completed",
    },
    db.doctors,
  );
  const becomesActive =
    isActive(rec) &&
    (!existing || !isActive(existing) || existing.date !== date || existing.doctorId !== doc.id);
  if (becomesActive) {
    if (!isDoctorAvailable(doc, date))
      throw new ClinicError("UNAVAILABLE", `${doc.name} is unavailable on ${fmtDate(date)}.`);
    if (countVisitsForDoctor(doc.id, date, db) >= doc.dailyLimit)
      throw new ClinicError("LIMIT", limitMessage(doc));
  }
  if (!v.scheduledTime && !existing) rec.scheduledTime = previewNextTime(doc.id, date, db);
  db.visits = existing ? db.visits.map((x) => (x.id === v.id ? rec : x)) : [...db.visits, rec];
  assignTimes(db, doc.id, date);
  write(LOCAL, db);
  emit();
  if (isOnline()) void syncNow();
  return db.visits.find((x) => x.id === rec.id)!;
}

// ---------- notifications ----------
export interface NotificationChannel {
  name: string;
  send(n: Notification, patient?: Patient): { ok: boolean; error?: string };
}
/** In-app channel. SMS / WhatsApp channels can implement the same interface using patient.phone. */
export const InAppChannel: NotificationChannel = { name: "in-app", send: () => ({ ok: true }) };
let channel: NotificationChannel = InAppChannel;
export const setNotificationChannel = (c: NotificationChannel) => {
  channel = c;
};

function upsertNotification(
  db: DB,
  n: Omit<Notification, "id" | "createdAt" | "updatedAt" | "readBy" | "syncStatus" | "channel">,
) {
  const existing = db.notifications.find((x) => x.key === n.key);
  if (existing && existing.status === "sent") return existing; // idempotent: never resend
  const now = nowIso();
  const rec: Notification = {
    ...n,
    id: existing?.id ?? newId("N"),
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
    readBy: existing?.readBy ?? [],
    channel: channel.name,
    syncStatus: "pending",
  };
  db.notifications = existing
    ? db.notifications.map((x) => (x.key === n.key ? rec : x))
    : [...db.notifications, rec];
  return rec;
}
function deliver(db: DB, n: Notification) {
  const r = channel.send(
    n,
    db.patients.find((p) => p.id === n.patientId),
  );
  const rec = {
    ...n,
    status: (r.ok ? "sent" : "failed") as NotificationStatus,
    updatedAt: nowIso(),
    syncStatus: "pending" as const,
  };
  db.notifications = db.notifications.map((x) => (x.id === n.id ? rec : x));
  notifyListeners.forEach((l) => l(rec));
  return rec;
}
export function confirmationMessage(v: Visit, patientName: string) {
  const base = `Confirmed: ${patientName}, your visit with ${v.doctor} is`;
  if (v.rescheduledFrom)
    return `${base} now on ${fmtDate(v.date)} at ${v.scheduledTime}. Your earlier session on ${fmtDate(v.rescheduledFrom)} was moved because the doctor was unavailable${v.rescheduleReason ? ` (${v.rescheduleReason})` : ""}.`;
  return `${base} on ${fmtDate(v.date)} at ${v.scheduledTime}.`;
}
/** Builds a patient confirmation and sends it through the active channel (queued while offline). */
export function sendConfirmation(visit: Visit, db = read(LOCAL), persist = true) {
  const p = db.patients.find((x) => x.id === visit.patientId);
  const v = db.visits.find((x) => x.id === visit.id) ?? visit;
  const kind: NotificationKind = v.rescheduledFrom ? "rescheduled" : "booking";
  const n = upsertNotification(db, {
    key: `${v.id}:${kind}:${v.date}`,
    patientId: v.patientId,
    visitId: v.id,
    doctorId: v.doctorId,
    doctorName: v.doctor,
    patientName: p?.name ?? "Patient",
    date: v.date,
    time: v.scheduledTime,
    kind,
    status: "queued",
    message: confirmationMessage(v, p?.name ?? "Patient"),
    audience: "patient",
  });
  const out = n.status === "sent" ? n : isOnline() ? deliver(db, n) : n;
  if (persist) {
    write(LOCAL, db);
    emit();
  }
  return out;
}
function internal(
  db: DB,
  kind: NotificationKind,
  audience: Audience,
  v: Visit,
  message: string,
  keySuffix = "",
) {
  const p = db.patients.find((x) => x.id === v.patientId);
  const n = upsertNotification(db, {
    key: `${v.id}:${kind}:${audience}:${v.date}${keySuffix}`,
    patientId: v.patientId,
    visitId: v.id,
    doctorId: v.doctorId,
    doctorName: v.doctor,
    patientName: p?.name ?? "Patient",
    date: v.date,
    time: v.scheduledTime,
    kind,
    status: "queued",
    message,
    audience,
  });
  return deliver(db, n); // in-app staff alerts are delivered on the device immediately
}

// ---------- receptionist operations ----------
export interface BookingResult {
  visit: Visit;
  notification: Notification;
  offline: boolean;
}
export function bookAppointment(input: {
  patientId: string;
  doctorId: string;
  date: string;
  priority?: boolean;
  symptoms?: string[];
}): BookingResult {
  requireRole("receptionist");
  const offline = !isOnline();
  const visit = saveVisit({
    id: newId("V"),
    patientId: input.patientId,
    doctorId: input.doctorId,
    doctor: "",
    date: input.date,
    visitDate: keyToDate(input.date).toISOString(),
    symptoms: input.symptoms ?? [],
    diagnosis: "",
    treatment: "",
    status: "scheduled",
    priority: !!input.priority,
    bookingStatus: offline ? "awaiting_sync" : "accepted",
  });
  const db = read(LOCAL);
  const v = db.visits.find((x) => x.id === visit.id)!;
  const p = db.patients.find((x) => x.id === v.patientId);
  internal(
    db,
    "new_appointment",
    "doctor",
    v,
    `New appointment: ${p?.name ?? "Patient"} on ${fmtDate(v.date)} at ${v.scheduledTime}${v.priority ? " (priority)" : ""}.`,
  );
  const notification = offline
    ? upsertNotification(db, {
        key: `${v.id}:booking:${v.date}`,
        patientId: v.patientId,
        visitId: v.id,
        doctorId: v.doctorId,
        doctorName: v.doctor,
        patientName: p?.name ?? "Patient",
        date: v.date,
        time: v.scheduledTime,
        kind: "booking",
        status: "queued",
        message: "Appointment saved offline. Confirmation will be sent when you are back online.",
        audience: "patient",
      })
    : sendConfirmation(v, db, false);
  write(LOCAL, db);
  emit();
  if (!offline) void syncNow();
  return { visit: v, notification, offline };
}
export function cancelAppointment(visitId: string) {
  requireRole("receptionist");
  const db = read(LOCAL);
  const v = db.visits.find((x) => x.id === visitId);
  if (!v) throw new ClinicError("NOT_FOUND", "Appointment not found.");
  const rec = {
    ...v,
    status: "cancelled" as const,
    updatedAt: nowIso(),
    syncStatus: "pending" as const,
  };
  db.visits = db.visits.map((x) => (x.id === visitId ? rec : x));
  assignTimes(db, v.doctorId, v.date);
  internal(
    db,
    "cancelled",
    "doctor",
    rec,
    `Appointment cancelled: ${db.patients.find((p) => p.id === v.patientId)?.name} on ${fmtDate(v.date)}.`,
  );
  write(LOCAL, db);
  emit();
  if (isOnline()) void syncNow();
  return rec;
}
export function rescheduleAppointment(
  visitId: string,
  newDate: string,
  reason = "Rescheduled at front desk",
) {
  requireRole("receptionist");
  const db = read(LOCAL);
  const v = db.visits.find((x) => x.id === visitId);
  if (!v) throw new ClinicError("NOT_FOUND", "Appointment not found.");
  const doc = db.doctors.find((d) => d.id === v.doctorId)!;
  if (!isDoctorAvailable(doc, newDate))
    throw new ClinicError("UNAVAILABLE", `${doc.name} is unavailable on ${fmtDate(newDate)}.`);
  if (countVisitsForDoctor(doc.id, newDate, db) >= doc.dailyLimit)
    throw new ClinicError("LIMIT", limitMessage(doc));
  const now = nowIso();
  const rec: Visit = {
    ...v,
    date: newDate,
    rescheduledFrom: v.date,
    originalDate: v.originalDate ?? v.date,
    rescheduleReason: reason,
    scheduledTime: "99:99",
    createdAt: now,
    rescheduleHistory: [
      ...(v.rescheduleHistory ?? []),
      { from: v.date, to: newDate, reason, at: now },
    ],
    updatedAt: now,
    syncStatus: "pending",
  };
  db.visits = db.visits.map((x) => (x.id === visitId ? rec : x));
  assignTimes(db, doc.id, v.date);
  assignTimes(db, doc.id, newDate);
  const fresh = db.visits.find((x) => x.id === visitId)!;
  internal(
    db,
    "rescheduled",
    "doctor",
    fresh,
    `Rescheduled: ${db.patients.find((p) => p.id === v.patientId)?.name} moved to ${fmtDate(newDate)} at ${fresh.scheduledTime}.`,
  );
  sendConfirmation(fresh, db, false);
  write(LOCAL, db);
  emit();
  if (isOnline()) void syncNow();
  return fresh;
}
export function setDailyLimit(doctorId: string, limit: number) {
  requireRole("receptionist");
  if (!Number.isInteger(limit) || limit < CLINIC_CONFIG.minLimit || limit > CLINIC_CONFIG.maxLimit)
    throw new ClinicError(
      "INVALID",
      `Daily limit must be between ${CLINIC_CONFIG.minLimit} and ${CLINIC_CONFIG.maxLimit}.`,
    );
  const db = read(LOCAL);
  db.doctors = db.doctors.map((d) =>
    d.id === doctorId ? { ...d, dailyLimit: limit, updatedAt: nowIso(), syncStatus: "pending" } : d,
  );
  write(LOCAL, db);
  emit();
  if (isOnline()) void syncNow();
}

// ---------- doctor operations ----------
export function markCompleted(visitId: string, notes?: { diagnosis?: string; treatment?: string }) {
  const u = requireRole("doctor");
  const db = read(LOCAL);
  const v = db.visits.find((x) => x.id === visitId);
  if (!v) throw new ClinicError("NOT_FOUND", "Visit not found.");
  requireDoctorScope(u, v.doctorId);
  const rec = {
    ...v,
    ...notes,
    status: "completed" as const,
    updatedAt: nowIso(),
    syncStatus: "pending" as const,
  };
  db.visits = db.visits.map((x) => (x.id === visitId ? rec : x));
  write(LOCAL, db);
  emit();
  if (isOnline()) void syncNow();
  return rec;
}
export const affectedByEmergency = (doctorId: string, date: string, db = read(LOCAL)) =>
  db.visits.filter((v) => v.doctorId === doctorId && v.date === date && v.status === "scheduled");

export interface RescheduleEvent {
  visitId: string;
  newDate: string;
  doctorId: string;
}
/** Marks a doctor unavailable and moves their scheduled patients to the next days with capacity, as priority visits. Works offline. */
export function handleDoctorEmergency(
  doctorId: string,
  date: string,
  reason: string,
): RescheduleEvent[] {
  const u = requireRole("doctor", "receptionist");
  requireDoctorScope(u, doctorId);
  if (!reason.trim()) throw new ClinicError("INVALID", "Please give a reason.");
  const db = read(LOCAL);
  const now = nowIso();
  const di = db.doctors.findIndex((d) => d.id === doctorId);
  if (di < 0) throw new ClinicError("NOT_FOUND", "Doctor not found.");
  const doc = {
    ...db.doctors[di]!,
    unavailableDates: [...new Set([...db.doctors[di]!.unavailableDates, date])].sort(),
    emergencyReasons: { ...db.doctors[di]!.emergencyReasons, [date]: reason },
    updatedAt: now,
    syncStatus: "pending" as const,
  };
  db.doctors[di] = doc;
  const affected = affectedByEmergency(doctorId, date, db).sort(
    (a, b) =>
      Number(b.priority) - Number(a.priority) || a.scheduledTime.localeCompare(b.scheduledTime),
  );
  const events: RescheduleEvent[] = [];
  let target = addDays(date, 1);
  const touched = new Set<string>();
  for (const [order, v] of affected.entries()) {
    let guard = 0;
    while (
      (!isDoctorAvailable(doc, target) ||
        countVisitsForDoctor(doctorId, target, db) >= doc.dailyLimit) &&
      guard++ < 730
    )
      target = addDays(target, 1);
    const moved: Visit = {
      ...v,
      date: target,
      priority: true,
      status: "scheduled",
      rescheduledFrom: date,
      originalDate: v.originalDate ?? date,
      rescheduleReason: reason,
      rescheduleHistory: [
        ...(v.rescheduleHistory ?? []),
        { from: date, to: target, reason, at: now },
      ],
      scheduledTime: `00:${String(order).padStart(2, "0")}`,
      updatedAt: now,
      syncStatus: "pending",
    };
    db.visits = db.visits.map((x) => (x.id === v.id ? moved : x));
    touched.add(target);
    events.push({ visitId: v.id, newDate: target, doctorId });
  }
  touched.forEach((d) => assignTimes(db, doctorId, d));
  for (const e of events) {
    const v = db.visits.find((x) => x.id === e.visitId)!;
    sendConfirmation(v, db, false);
    internal(
      db,
      "rescheduled",
      "doctor",
      v,
      `Priority patient moved from ${fmtDate(date)} to ${fmtDate(v.date)} at ${v.scheduledTime}.`,
      `:em${date}`,
    );
  }
  const fake = {
    id: `EM-${doctorId}-${date}`,
    patientId: "",
    doctor: doc.name,
    doctorId,
    date,
    scheduledTime: "",
  } as Visit;
  internal(
    db,
    "emergency",
    "reception",
    fake,
    `${doc.name} is unavailable on ${fmtDate(date)} (${reason}). ${events.length} appointment(s) moved.`,
  );
  write(LOCAL, db);
  emit();
  if (isOnline()) void syncNow();
  return events;
}

// ---------- sync engine (last-updated-wins, idempotent by device-generated id) ----------
let syncing = false;
let syncFailed = false;
let syncDelay = 1200;
export const setSyncDelay = (ms: number) => {
  syncDelay = ms;
};
export const isSyncing = () => syncing;
export const hasSyncFailed = () => syncFailed;
export type ConnectionState = "online" | "offline" | "syncing" | "failed";
export const connectionState = (): ConnectionState =>
  syncing ? "syncing" : !isOnline() ? "offline" : syncFailed ? "failed" : "online";
export interface SyncResult {
  uploaded: number;
  at: string;
}
let lastSync: SyncResult | null = null;
export const getLastSync = () => lastSync;

export function mergeLWW<T extends { id: string; updatedAt: string }>(
  server: T[],
  incoming: T[],
): T[] {
  const map = new Map(server.map((s) => [s.id, s]));
  for (const r of incoming) {
    const cur = map.get(r.id);
    if (!cur || new Date(r.updatedAt) >= new Date(cur.updatedAt)) map.set(r.id, r);
  }
  return [...map.values()];
}

export async function syncNow(): Promise<SyncResult | null> {
  if (syncing || !isOnline()) return null;
  const local = read(LOCAL);
  const pending = <T extends { syncStatus: SyncStatus }>(xs: T[]) =>
    xs.filter((x) => x.syncStatus === "pending");
  const pp = pending(local.patients),
    pv = pending(local.visits),
    pd = pending(local.doctors),
    pn = pending(local.notifications);
  if (!pp.length && !pv.length && !pd.length && !pn.length) {
    cleanup();
    return null;
  }
  syncing = true;
  emit();
  try {
    if (syncDelay) await new Promise((r) => setTimeout(r, syncDelay)); // simulated network
    if (!isOnline()) return null;
    const server = read(SERVER);
    const mark = <T extends { syncStatus: SyncStatus }>(x: T) => ({
      ...x,
      syncStatus: "synced" as const,
    });
    server.patients = mergeLWW(server.patients, pp.map(mark));
    server.doctors = mergeLWW(server.doctors, pd.map(mark));
    // server-side validation of offline bookings
    const validated: Visit[] = [];
    for (const v of pv) {
      let rec = mark(v);
      if (v.bookingStatus === "awaiting_sync") {
        const doc = server.doctors.find((d) => d.id === v.doctorId);
        const others = server.visits.filter(
          (x) => x.id !== v.id && x.doctorId === v.doctorId && x.date === v.date && isActive(x),
        ).length;
        if (!doc || !isDoctorAvailable(doc, v.date))
          rec = {
            ...rec,
            status: "cancelled",
            bookingStatus: "rejected",
            bookingNote: `${v.doctor} is unavailable on ${fmtDate(v.date)}.`,
          };
        else if (others >= doc.dailyLimit)
          rec = {
            ...rec,
            bookingStatus: "over_limit",
            bookingNote: "Over limit – needs attention",
          };
        else rec = { ...rec, bookingStatus: "accepted" };
        validated.push(rec);
      }
      server.visits = mergeLWW(server.visits, [rec]);
    }
    server.notifications = mergeLWW(server.notifications, pn.map(mark));
    write(SERVER, server);
    const ids = new Set([...pp, ...pv, ...pd, ...pn].map((x) => x.id));
    const fresh = read(LOCAL);
    const sameVer = <T extends { id: string; updatedAt: string; syncStatus: SyncStatus }>(
      xs: T[],
      src: T[],
    ) =>
      xs.map((x) =>
        ids.has(x.id) && src.find((q) => q.id === x.id)?.updatedAt === x.updatedAt ? mark(x) : x,
      );
    fresh.patients = sameVer(fresh.patients, pp);
    fresh.doctors = sameVer(fresh.doctors, pd);
    fresh.notifications = sameVer(fresh.notifications, pn);
    fresh.visits = sameVer(fresh.visits, pv).map((x) => {
      const s = validated.find((y) => y.id === x.id);
      return s && x.syncStatus === "synced" ? s : x;
    });
    // pull server changes (e.g. other devices) — last updated wins
    fresh.doctors = mergeLWW(fresh.doctors, server.doctors);
    fresh.visits = mergeLWW(
      fresh.visits,
      server.visits.filter(
        (v) =>
          fresh.visits.some((x) => x.id === v.id) ||
          new Date(v.visitDate).getTime() >= Date.now() - RETENTION_DAYS * 864e5,
      ),
    );
    fresh.notifications = mergeLWW(fresh.notifications, server.notifications);
    // follow-up notifications for validated offline bookings
    for (const v of validated) {
      if (v.bookingStatus === "accepted") sendConfirmation(v, fresh, false);
      else {
        const p = fresh.patients.find((x) => x.id === v.patientId);
        const n = upsertNotification(fresh, {
          key: `${v.id}:booking:${v.date}`,
          patientId: v.patientId,
          visitId: v.id,
          doctorId: v.doctorId,
          doctorName: v.doctor,
          patientName: p?.name ?? "Patient",
          date: v.date,
          time: v.scheduledTime,
          kind: v.bookingStatus === "rejected" ? "rejected" : "over_limit",
          status: "failed",
          message:
            v.bookingStatus === "rejected"
              ? `Booking rejected: ${v.bookingNote}`
              : `Booking for ${p?.name} with ${v.doctor} on ${fmtDate(v.date)} is over the daily limit – needs attention.`,
          audience: "patient",
        });
        notifyListeners.forEach((l) => l(n));
      }
    }
    // flush queued patient confirmations created while offline
    for (const n of fresh.notifications.filter(
      (x) => x.status === "queued" && x.audience === "patient",
    )) {
      const v = fresh.visits.find((x) => x.id === n.visitId);
      if (
        v &&
        v.bookingStatus !== "awaiting_sync" &&
        v.bookingStatus !== "rejected" &&
        v.bookingStatus !== "over_limit"
      ) {
        fresh.notifications = fresh.notifications.map((x) =>
          x.id === n.id
            ? { ...x, message: confirmationMessage(v, n.patientName), time: v.scheduledTime }
            : x,
        );
        deliver(
          fresh,
          fresh.notifications.find((x) => x.id === n.id)!,
        );
      }
    }
    // push the follow-up notifications too
    const after = pending(fresh.notifications);
    server.notifications = mergeLWW(server.notifications, after.map(mark));
    write(SERVER, server);
    fresh.notifications = fresh.notifications.map((x) =>
      after.some((a) => a.id === x.id && a.updatedAt === x.updatedAt) ? mark(x) : x,
    );
    write(LOCAL, fresh);
    syncFailed = false;
    lastSync = { uploaded: ids.size, at: nowIso() };
    cleanup();
    return lastSync;
  } catch (e) {
    syncFailed = true;
    console.error("Sync failed", e);
    return null;
  } finally {
    syncing = false;
    emit();
  }
}

/** Remove local visits older than retention, but ONLY if already synced. */
export function cleanup(now = Date.now()) {
  const db = read(LOCAL);
  const cutoff = now - RETENTION_DAYS * 864e5;
  const before = db.visits.length;
  db.visits = db.visits.filter(
    (v) => new Date(v.visitDate).getTime() >= cutoff || v.syncStatus !== "synced",
  );
  const removed = before - db.visits.length;
  if (removed) {
    write(LOCAL, db);
    emit();
  }
  return removed;
}

export function initClinic() {
  ensureSeed();
  cleanup();
  const on = () => {
    emit();
    void syncNow();
  };
  window.addEventListener("online", on);
  window.addEventListener("offline", emit);
  const t = setInterval(() => {
    void syncNow();
  }, 15000);
  void syncNow();
  return () => {
    window.removeEventListener("online", on);
    window.removeEventListener("offline", emit);
    clearInterval(t);
  };
}
